# System Architecture & Layered Design

## Overview
The Smart Library Management System is engineered using a multi-tiered, decoupled architecture where the graphical presentation layer is built exclusively using **Java Applet + Pure AWT**, completely isolated from the business logic, collection storage, multi-threaded execution engine, and persistent database layers.

---

## 1. Architectural Diagram

```text
+-----------------------------------------------------------------------------------+
|                           PRESENTATION LAYER (GUI)                                |
|                                                                                   |
|   +---------------------------------------------------------------------------+   |
|   |                 SmartLibraryApplet extends java.applet.Applet            |   |
|   |                                                                           |   |
|   |  - Lifecycle: init(), start(), paint(), stop(), destroy()                 |   |
|   |  - AWT Components: Panel, Label, TextField, TextArea, Button, Choice, List|   |
|   |  - AWT Menus: MenuBar, Menu, MenuItem                                     |   |
|   |  - Layout Managers: BorderLayout, GridLayout, FlowLayout, CardLayout      |   |
|   |  - Event Model: ActionListener, ItemListener, WindowListener              |   |
|   +---------------------------------------------------------------------------+   |
+------------------------------------------+----------------------------------------+
                                           |
                                           v
+-----------------------------------------------------------------------------------+
|                              SERVICE LAYER                                        |
|                                                                                   |
|  +--------------------+  +--------------------+  +-----------------------------+  |
|  |   MemberService    |  |    BookService     |  |     ReservationService      |  |
|  | (HashMap, Iterator)|  | (ArrayList, Set,   |  |     (FIFO Waitlist Queue,   |  |
|  |                    |  |  ListIterator)     |  |      Duplicate Prevention)  |  |
|  +--------------------+  +--------------------+  +-----------------------------+  |
|                                                                                   |
|  +--------------------------------------------+  +-----------------------------+  |
|  |              LibraryService                |  |        ReportService        |  |
|  |  (Issue, Return, Transactions, Overdue)    |  | (Circulation, Fines, Util%) |  |
|  +--------------------------------------------+  +-----------------------------+  |
+-------------------+----------------------+-------------------+--------------------+
                    |                      |                   |
                    v                      v                   v
+-----------------------+  +-------------------+  +---------------------------------+
|      MODEL LAYER      |  | MULTITHREADING    |  |    PERSISTENCE & UTILITIES      |
|                       |  |                   |  |                                 |
|  Member (Abstract)    |  | ThreadCoordinator |  | DatabaseManager (JDBC/MySQL)    |
|   - StudentMember     |  | IssueProcessing   |  |  - PreparedStatements           |
|   - FacultyMember     |  |  (MAX_PRIORITY 10)|  |  - ResultSet Mapping            |
|   - PremiumMember     |  | OverdueDaemon     |  |  - ACID Transactions            |
|                       |  |  (MIN_PRIORITY 1) |  | FileReportWriter (Char/Byte I/O)|
|  Book (Abstract)      |  |                   |  | BackupManager (Serialization)   |
|   - RegularBook       |  | Shared Resource:  |  | HashUtil (SHA-256 Digest)       |
|   - ReferenceBook     |  |  Inventory        |  | InputValidator (Form Rules)     |
|   - EBook             |  |  (synchronized,   |  +---------------------------------+
|  Reservation          |  |   wait/notifyAll) |
|  Notification (Base)  |  +-------------------+
|   - DueNotification   |
|   - OverdueNotif      |
+-----------------------+
```

---

## 2. Layer Responsibilities & Separation of Concerns

### Presentation Layer (`SmartLibraryApplet`, `AppletRunner`)
- Manages user interactions, graphical components rendering, and menu dispatch.
- Strictly captures user actions via Delegation Event Model and forwards sanitized input to the Service Layer.
- Formats exceptions and success confirmations for display in AWT `TextArea` and status bar labels.
- **Zero SQL queries or raw database logic exist in the presentation layer.**

### Service Layer (`service.*`)
- Implements core business logic, validation workflows, loan period arithmetic, fine computation, and waitlist fulfillment.
- Coordinates collections and acts as the orchestrator between models and the persistence engine.

### Model Layer (`model.*`, `notification.*`)
- Pure domain models encapsulating private state variables with getter/setter methods.
- Implements inheritance hierarchies and polymorphism for fines, borrowing limits, book lendability, and notifications.

### Multithreading Layer (`thread.*`)
- Employs dedicated worker threads competing for the shared `Inventory` resource.
- Employs `Thread.MAX_PRIORITY` and `Thread.MIN_PRIORITY` to demonstrate CPU scheduling precedence.
- Synchronizes stock mutations and executes inter-thread communication via `wait()` and `notifyAll()`.

### Persistence & Utility Layer (`database.*`, `util.*`)
- `DatabaseManager`: Pure JDBC persistence with `PreparedStatement` parameterized queries and transaction rollbacks.
- `FileReportWriter`: Character and byte streams for report exports and binary clones.
- `BackupManager`: Full snapshot state serialization (`ObjectOutputStream`/`ObjectInputStream`).
- `HashUtil`: 256-bit cryptographic digest hashing for payload and file verification.
