# Class Design & Object-Oriented Analysis

## 1. Class Hierarchy & Inheritance

### 1.1 Member Hierarchy
```text
                  +-----------------------------------+
                  |          Member (Abstract)        |
                  +-----------------------------------+
                  | - memberId: int                   |
                  | - name: String                    |
                  | - email: String                   |
                  | - memberType: String              |
                  | - currentIssuedCount: int         |
                  +-----------------------------------+
                  | + calculateFine(days: int): double|
                  | + getBorrowLimit(): int           |
                  | + canBorrow(): boolean            |
                  +-----------------+-----------------+
                                    |
          +-------------------------+-------------------------+
          |                         |                         |
+-------------------+     +-------------------+     +-------------------+
|   StudentMember   |     |   FacultyMember   |     |   PremiumMember   |
+-------------------+     +-------------------+     +-------------------+
| Limit: 3 books    |     | Limit: 10 books   |     | Limit: 15 books   |
| Fine: ₹2.00 / day |     | Fine: ₹1.00 / day |     | Fine: ₹0.50 / day |
+-------------------+     +-------------------+     +-------------------+
```

### 1.2 Book Hierarchy
```text
                  +-----------------------------------+
                  |           Book (Abstract)         |
                  +-----------------------------------+
                  | - bookId: int                     |
                  | - title: String                   |
                  | - author: String                  |
                  | - category: String                |
                  | - bookType: String                |
                  | - totalCopies: int                |
                  | - availableCopies: int            |
                  +-----------------------------------+
                  | + isLendable(): boolean           |
                  | + getDefaultLoanDays(): int       |
                  +-----------------+-----------------+
                                    |
          +-------------------------+-------------------------+
          |                         |                         |
+-------------------+     +-------------------+     +-------------------+
|    RegularBook    |     |   ReferenceBook   |     |       EBook       |
+-------------------+     +-------------------+     +-------------------+
| Lendable: true    |     | Lendable: false   |     | Lendable: true    |
| Loan: 14 days     |     | Loan: 0 days      |     | Loan: 21 days     |
+-------------------+     +-------------------+     +-------------------+
```

### 1.3 Notification Hierarchy
```text
                  +-----------------------------------+
                  |       Notification (Abstract)     |
                  +-----------------------------------+
                  | - notificationId: int             |
                  | - memberId: int                   |
                  | - message: String                 |
                  | - notificationType: String        |
                  | - createdAt: Date                 |
                  +-----------------------------------+
                  | + formatNotification(): String    |
                  +-----------------+-----------------+
                                    |
                    +---------------+---------------+
                    |                               |
          +-------------------+           +-------------------+
          |  DueNotification  |           |OverdueNotification|
          +-------------------+           +-------------------+
          | Upcoming reminder |           | Overdue fine      |
          | formatting        |           | assessment format |
          +-------------------+           +-------------------+
```

---

## 2. Core Model Classes Summary

| Class Name | Package | Responsibilities | Key Fields & Encapsulation |
|---|---|---|---|
| `Member` | `model` | Base member entity declaring polymorphic contracts | `private int memberId`, `private String name`, `email`, `memberType`, `currentIssuedCount` |
| `StudentMember` | `model` | Subclass implementing Student policies | Overrides `getBorrowLimit()` $\to 3$, `calculateFine()` $\to ₹2.00/\text{day}$ |
| `FacultyMember` | `model` | Subclass implementing Faculty policies | Overrides `getBorrowLimit()` $\to 10$, `calculateFine()` $\to ₹1.00/\text{day}$ |
| `PremiumMember` | `model` | Subclass implementing Premium policies | Overrides `getBorrowLimit()` $\to 15$, `calculateFine()` $\to ₹0.50/\text{day}$ |
| `Book` | `model` | Base book catalog entity | `private int bookId`, `title`, `author`, `category`, `totalCopies`, `availableCopies` |
| `RegularBook` | `model` | Physical loanable book | `isLendable() = true`, `getDefaultLoanDays() = 14` |
| `ReferenceBook` | `model` | Reading-room reference material | `isLendable() = false`, `getDefaultLoanDays() = 0` |
| `EBook` | `model` | Digital resource | `isLendable() = true`, `getDefaultLoanDays() = 21` |
| `Reservation` | `model` | Waitlist reservation model | `private int reservationId`, `memberId`, `bookId`, `reservationDate`, `status` |
| `Inventory` | `model` | Thread-safe shared stock resource | `private Hashtable<Integer, Integer> availableStock`, `totalStock` |
| `IssuedBook` | `model` | Circulation checkout record | `private int issueId`, `memberId`, `bookId`, `issueDate`, `dueDate`, `returnDate`, `fine` |
| `Notification` | `model` | Base notification entity | `private int notificationId`, `memberId`, `message`, `notificationType`, `createdAt` |
| `DueNotification` | `notification` | Formats due-date reminders | `private int bookId`, `bookTitle`, `dueDate` |
| `OverdueNotification`| `notification` | Formats overdue fine notices | `private int overdueDays`, `double fineAmount` |

---

## 3. Collections & Data Structures Mapping

- **`ArrayList<Book>`**: Maintains ordered collection of catalog titles in `BookService`.
- **`HashMap<Integer, Member>`**: Maps Member ID $\to$ `Member` object in `MemberService` for $O(1)$ fast lookups.
- **`HashSet<String>`**: Ensures unique set of book categories in `BookService`.
- **`Hashtable<Integer, Integer>`**: Maps Book ID $\to$ available stock copies in `Inventory` with synchronized concurrency safety.
- **`Iterator<Book>` / `Iterator<Member>`**: Traverses, searches, and filters entities without exposing internal array structures.
- **`ListIterator<Book>`**: Enables bidirectional navigation and in-place element replacement (`set()`) during catalog updates.
