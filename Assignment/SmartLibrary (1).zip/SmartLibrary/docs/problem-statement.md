# Problem Statement & Formulation

## Course: CSA09 – Programming in Java (Slot A)
## Project Title: Smart Library Management, Book Reservation & Overdue Notification System

---

## 1. Context & Background
Academic and research libraries struggle with managing resource circulation, waitlist contention, and overdue loan enforcement when manual or loosely connected systems are employed. Without thread-safe inventory synchronization and automated fine governance, libraries encounter race conditions (e.g. issuing books beyond zero stock), delayed notifications, and inconsistent inventory utilization metrics.

## 2. Problem Formulation
The goal of this project is to architect, design, and implement an end-to-end academic library management platform strictly using **Java Applet and Abstract Window Toolkit (AWT)** as the primary GUI, integrated with robust Object-Oriented Principles, Java Collections Framework, Multi-Threaded concurrency with inter-thread communication (`wait()` / `notifyAll()`), Custom Exception hierarchies, JDBC database persistence, Java I/O streams, Java Object Serialization, and SHA-256 cryptographic hashing.

---

## 3. Core Objectives
1. **Applet & AWT Interface**: Deliver a complete graphical interface extending `java.applet.Applet` that demonstrates the full Applet lifecycle (`init()`, `start()`, `paint()`, `stop()`, `destroy()`), AWT container layouts (`BorderLayout`, `GridLayout`, `FlowLayout`, `CardLayout`), components (`Label`, `TextField`, `TextArea`, `Button`, `Choice`, `List`, `Panel`, `MenuBar`, `Menu`, `MenuItem`), and the Java Delegation Event Model.
2. **Encapsulation, Inheritance & Polymorphism (CO1)**:
   - Establish `Member` hierarchy (`StudentMember`, `FacultyMember`, `PremiumMember`) exhibiting polymorphic borrowing limits (3, 10, 15) and fine rates (₹2.00, ₹1.00, ₹0.50 per day).
   - Establish `Book` hierarchy (`RegularBook`, `ReferenceBook`, `EBook`) with distinct lending eligibility and loan duration policies.
   - Establish `Notification` hierarchy (`DueNotification`, `OverdueNotification`).
3. **Collections Framework & Generics (CO2)**:
   - `ArrayList<Book>` for book catalog maintenance.
   - `HashMap<Integer, Member>` for O(1) primary key member lookup.
   - `HashSet<String>` for unique book categories collection.
   - `Hashtable<Integer, Integer>` for thread-safe inventory stock mapping.
   - `Iterator<Book>` and `Iterator<Member>` for traversal and searching.
   - `ListIterator<Book>` for in-place updates.
4. **Exception Handling & Validation (CO3)**:
   - Define custom checked exceptions: `InvalidMemberException`, `BookUnavailableException`, `DuplicateReservationException`, `BorrowLimitExceededException`, `BookNotFoundException`, `InvalidInputException`.
   - Prevent application crashes upon invalid input through GUI feedback dialogs/text areas.
5. **Multithreading & Synchronization (CO3)**:
   - Implement concurrent worker threads: `IssueProcessingThread` (Priority 10 / `MAX_PRIORITY`) and `OverdueNotificationThread` (Priority 1 / `MIN_PRIORITY`).
   - Protect shared `Inventory` monitor using `synchronized` methods.
   - Coordinate threads using inter-thread communication (`wait()` when stock is 0, and `notifyAll()` upon book return).
6. **Persistence, I/O & Security (CO5)**:
   - JDBC MySQL connectivity using `PreparedStatement`, `ResultSet`, and ACID transactions (`setAutoCommit(false)`, `commit()`, `rollback()`).
   - Character Streams (`FileWriter`, `BufferedWriter`, `FileReader`, `BufferedReader`) for human-readable reports.
   - Byte Streams (`FileInputStream`, `FileOutputStream`) for binary file copying and checksum computation.
   - Object Serialization (`BackupManager` with `ObjectOutputStream` / `ObjectInputStream`) for state backup/restore (`library_backup.ser`).
   - Cryptographic SHA-256 integrity validation (`HashUtil`).

---

## 4. Constraints & Academic Compliance
- **GUI Restriction**: Strictly Java Applet + Pure AWT. No Swing (`JFrame`, `JPanel`), JavaFX, React, or console-only UI.
- **Dual Execution**: Compatible with JDK 8 `appletviewer applet.html` and pure AWT Frame `AppletRunner` for universal demonstration.
- **Decoupled Architecture**: High cohesion, low coupling, strict separation of Applet GUI, Service layer, Model layer, Thread layer, DatabaseManager, and Utility modules.
