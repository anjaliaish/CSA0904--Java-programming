# Software Requirements Specification (SRS)

## Course: CSA09 – Programming in Java | Slot A
## Project: Smart Library Management, Book Reservation & Overdue Notification System

---

## 1. Functional Requirements

### FR-1: Member Management
- **FR-1.1**: The system shall register library members into three polymorphic tiers: `StudentMember`, `FacultyMember`, and `PremiumMember`.
- **FR-1.2**: The system shall store members in a `HashMap<Integer, Member>` for $O(1)$ constant-time lookup and persist records in MySQL.
- **FR-1.3**: The system shall enforce duplicate member ID and unique email constraints, throwing `InvalidMemberException`.
- **FR-1.4**: The system shall allow member search using `Iterator<Member>` traversal and permit updates/deletions.

### FR-2: Book Catalog & Inventory Management
- **FR-2.1**: The system shall manage books classified as `RegularBook`, `ReferenceBook`, and `EBook`.
- **FR-2.2**: The catalog shall be maintained in an `ArrayList<Book>`, unique categories in a `HashSet<String>`, and stock levels in a thread-safe `Hashtable<Integer, Integer>` inside `Inventory`.
- **FR-2.3**: The system shall support in-place book updates using `ListIterator<Book>`.
- **FR-2.4**: The system shall prevent deletion of books with active borrowed copies.

### FR-3: Circulation (Issue & Return)
- **FR-3.1**: The system shall issue books only after validating member existence, borrow quota (`Student`: 3, `Faculty`: 10, `Premium`: 15), lendability status (Reference books cannot be issued), and positive inventory stock.
- **FR-3.2**: Transactions shall be executed via ACID JDBC transactions (`setAutoCommit(false)`, `commit()`, `rollback()`).
- **FR-3.3**: Upon return, the system shall compute overdue days and polymorphically calculate accrued fines:
  $$\text{Fine} = \text{Overdue Days} \times \text{Daily Rate}$$
  ($\text{Student} = ₹2.00/\text{day}, \text{Faculty} = ₹1.00/\text{day}, \text{Premium} = ₹0.50/\text{day}$).
- **FR-3.4**: When a returned book has pending reservations, the system shall automatically fulfill the next FIFO reservation and dispatch a readiness notification.

### FR-4: Book Reservation & Waitlist
- **FR-4.1**: Members may place a reservation when available stock is 0.
- **FR-4.2**: Duplicate active reservations for the same member and book shall throw `DuplicateReservationException`.
- **FR-4.3**: Active reservations can be cancelled, updating status to `CANCELLED`.

### FR-5: Overdue Notifications & Scanner
- **FR-5.1**: The system shall provide a notification hierarchy: `DueNotification` and `OverdueNotification`.
- **FR-5.2**: The system shall scan active loans and generate polymorphic alerts.

### FR-6: Multithreading & Synchronization
- **FR-6.1**: Concurrent issue and return threads shall access shared `Inventory` monitor protected by `synchronized` methods.
- **FR-6.2**: `IssueProcessingThread` (Priority 10 / `MAX_PRIORITY`) shall enter `wait()` when stock is 0.
- **FR-6.3**: Return operations shall increment stock and trigger `notifyAll()`.
- **FR-6.4**: `OverdueNotificationThread` (Priority 1 / `MIN_PRIORITY`) shall run periodic background scans.

### FR-7: Reports, File I/O & Serialization
- **FR-7.1**: The system shall generate Circulation, Inventory Utilization %, and Fine reports.
- **FR-7.2**: Character streams (`FileWriter`, `BufferedWriter`) shall export reports to `reports/library_report.txt`.
- **FR-7.3**: Java Object Serialization (`ObjectOutputStream`, `ObjectInputStream`) shall save/restore complete state to `backups/library_backup.ser`.
- **FR-7.4**: Cryptographic SHA-256 digests (`HashUtil`) shall verify state and file integrity.

---

## 2. Non-Functional Requirements

- **NFR-1: GUI Technology**: 100% Java Applet (`extends Applet`) + Pure AWT Components. No Swing or external GUI toolkits.
- **NFR-2: Thread Safety**: Zero race conditions on stock decrements/increments.
- **NFR-3: Reliability & Robustness**: Comprehensive exception handling; application never terminates unexpectedly on invalid user input.
- **NFR-4: Dual Execution**: Seamlessly executable via `appletviewer applet.html` or `AppletRunner` harness.
