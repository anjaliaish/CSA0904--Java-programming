import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;

/**
 * AppletRunner - Pure AWT Frame Host Harness for SmartLibraryApplet.
 * 
 * Purpose:
 * Provides a universal execution host for environments where the legacy browser plugin 
 * or JDK `appletviewer` utility is absent, while strictly executing the EXACT 
 * SmartLibraryApplet instance and invoking its complete Applet lifecycle:
 *   1. applet.init()
 *   2. applet.start()
 *   3. applet.paint(g)
 *   4. applet.stop()
 *   5. applet.destroy()
 * 
 * Demonstrates AWT WindowListener interface on an AWT Frame.
 */
public class AppletRunner extends Frame implements WindowListener {

    private final SmartLibraryApplet appletInstance;

    public AppletRunner() {
        super("Smart Library Management System [AWT Applet Host]");
        setLayout(new BorderLayout());
        setSize(new Dimension(980, 720));
        setLocationRelativeTo(null);

        // Instantiate the primary Applet
        appletInstance = new SmartLibraryApplet();

        // Add pure Applet component to AWT Frame
        add(appletInstance, BorderLayout.CENTER);

        // Register AWT WindowListener
        addWindowListener(this);

        // 1. Invoke Applet Lifecycle: init()
        appletInstance.init();

        setVisible(true);

        // 2. Invoke Applet Lifecycle: start()
        appletInstance.start();
    }

    public static void main(String[] args) {
        new AppletRunner();
    }

    // =========================================================================
    // AWT WINDOW LISTENER IMPLEMENTATION
    // =========================================================================

    @Override
    public void windowOpened(WindowEvent e) {}

    @Override
    public void windowClosing(WindowEvent e) {
        // 3. Invoke Applet Lifecycle: stop() and destroy() on exit
        if (appletInstance != null) {
            appletInstance.stop();
            appletInstance.destroy();
        }
        dispose();
        System.exit(0);
    }

    @Override
    public void windowClosed(WindowEvent e) {}

    @Override
    public void windowIconified(WindowEvent e) {
        if (appletInstance != null) {
            appletInstance.stop();
        }
    }

    @Override
    public void windowDeiconified(WindowEvent e) {
        if (appletInstance != null) {
            appletInstance.start();
        }
    }

    @Override
    public void windowActivated(WindowEvent e) {}

    @Override
    public void windowDeactivated(WindowEvent e) {}
}
