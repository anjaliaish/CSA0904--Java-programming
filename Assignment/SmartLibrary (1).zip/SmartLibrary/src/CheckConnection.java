import database.DatabaseManager;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.Statement;

public class CheckConnection {
    public static void main(String[] args) {
        System.out.println("=================================================");
        System.out.println("          MYSQL DATABASE CONNECTION TEST         ");
        System.out.println("=================================================");

        DatabaseManager db = new DatabaseManager();
        boolean connected = db.testConnection();

        if (connected) {
            System.out.println("Status  : [SUCCESS] CONNECTED TO MYSQL DATABASE!");
            try (Connection conn = db.getConnection()) {
                DatabaseMetaData meta = conn.getMetaData();
                System.out.println("Database: " + conn.getCatalog());
                System.out.println("Product : " + meta.getDatabaseProductName() + " " + meta.getDatabaseProductVersion());
                System.out.println("Driver  : " + meta.getDriverName() + " " + meta.getDriverVersion());
                System.out.println("URL     : " + meta.getURL());
                System.out.println("User    : " + meta.getUserName());

                System.out.println("\n--- Current Table Record Counts ---");
                Statement stmt = conn.createStatement();
                String[] tables = {"members", "books", "reservations", "issued_books", "notifications"};
                for (String tbl : tables) {
                    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) FROM " + tbl);
                    if (rs.next()) {
                        System.out.printf(" - %-15s : %d rows\n", tbl, rs.getInt(1));
                    }
                }
            } catch (Exception e) {
                System.out.println("Error reading metadata: " + e.getMessage());
            }
        } else {
            System.out.println("Status  : [FAILED] Could not connect to MySQL.");
        }
        System.out.println("=================================================");
    }
}
