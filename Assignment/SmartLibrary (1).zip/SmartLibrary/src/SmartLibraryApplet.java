import database.DatabaseManager;
import exception.BookNotFoundException;
import exception.BookUnavailableException;
import exception.BorrowLimitExceededException;
import exception.DuplicateReservationException;
import exception.InvalidInputException;
import exception.InvalidMemberException;
import model.Book;
import model.Inventory;
import model.IssuedBook;
import model.Member;
import model.Notification;
import model.Reservation;
import service.BookService;
import service.LibraryService;
import service.MemberService;
import service.ReportService;
import service.ReservationService;
import thread.ThreadCoordinator;
import util.BackupManager;
import util.FileReportWriter;
import util.HashUtil;
import util.InputValidator;

import java.applet.Applet;
import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Panel;
import java.awt.TextArea;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

/**
 * SmartLibraryApplet - The primary evaluated Graphical User Interface.
 * 
 * Strict Architectural Compliance:
 *  - Extends java.applet.Applet
 *  - Implements full Applet lifecycle: init(), start(), paint(), stop(), destroy()
 *  - Pure AWT Components (Panel, Label, TextField, TextArea, Button, Choice, MenuBar, Menu, MenuItem)
 *  - Standard AWT Layout Managers (BorderLayout, GridLayout, FlowLayout, CardLayout)
 *  - Java Delegation Event Model (ActionListener, ItemListener)
 */
public class SmartLibraryApplet extends Applet implements ActionListener, ItemListener {

    // Backend Core Architecture
    private DatabaseManager dbManager;
    private Inventory inventory;
    private MemberService memberService;
    private BookService bookService;
    private ReservationService reservationService;
    private LibraryService libraryService;
    private ReportService reportService;
    private ThreadCoordinator threadCoordinator;

    // Card Layout Container for Dynamic Panel Navigation
    private CardLayout cardLayout;
    private Panel contentCardsPanel;
    private Label statusBarLabel;

    // Navigation Buttons
    private Button btnNavMembers;
    private Button btnNavBooks;
    private Button btnNavCirculation;
    private Button btnNavReservations;
    private Button btnNavNotifications;
    private Button btnNavReports;
    private Button btnNavBackup;
    private Button btnNavThreading;

    // 1. Member Management Components
    private TextField txtMemberId;
    private TextField txtMemberName;
    private TextField txtMemberEmail;
    private Choice choiceMemberType;
    private TextField txtMemberSearch;
    private TextArea areaMemberOutput;
    private Button btnMemberRegister;
    private Button btnMemberSearch;
    private Button btnMemberUpdate;
    private Button btnMemberDelete;
    private Button btnMemberListAll;

    // 2. Book Management Components
    private TextField txtBookId;
    private TextField txtBookTitle;
    private TextField txtBookAuthor;
    private TextField txtBookCategory;
    private Choice choiceBookType;
    private TextField txtBookCopies;
    private TextField txtBookSearch;
    private TextArea areaBookOutput;
    private Button btnBookAdd;
    private Button btnBookSearch;
    private Button btnBookUpdate;
    private Button btnBookDelete;
    private Button btnBookListAll;
    private Button btnBookCheckStock;

    // 3. Issue / Return Components
    private TextField txtCircMemberId;
    private TextField txtCircBookId;
    private TextArea areaCircOutput;
    private Button btnCircIssue;
    private Button btnCircReturn;
    private Button btnCircListActive;

    // 4. Reservation Components
    private TextField txtResMemberId;
    private TextField txtResBookId;
    private TextField txtResCancelId;
    private TextArea areaResOutput;
    private Button btnResCreate;
    private Button btnResCancel;
    private Button btnResListWaitlist;

    // 5. Notification Components
    private TextArea areaNotifOutput;
    private Button btnNotifScanOverdue;
    private Button btnNotifListAll;

    // 6. Reports Components
    private TextArea areaReportOutput;
    private Button btnReportCirculation;
    private Button btnReportInventory;
    private Button btnReportFines;
    private Button btnReportComprehensive;
    private Button btnReportExport;

    // 7. Backup & Restore Components
    private TextArea areaBackupOutput;
    private Button btnBackupSave;
    private Button btnBackupRestore;
    private Button btnBackupVerifyHash;

    // 8. Multithreading Components
    private TextArea areaThreadOutput;
    private Button btnThreadRunDemo;

    // =========================================================================
    // APPLET LIFECYCLE METHODS
    // =========================================================================

    @Override
    public void init() {
        // Step 1: Initialize Backend Services
        initServices();

        // Step 2: Initialize GUI Components and Layout
        setLayout(new BorderLayout(5, 5));
        setBackground(new Color(240, 243, 246));

        // Top Navigation Header
        Panel topPanel = new Panel(new BorderLayout());
        topPanel.setBackground(new Color(33, 43, 54));

        Label titleLabel = new Label("SMART LIBRARY MANAGEMENT SYSTEM (JAVA APPLET + AWT)", Label.CENTER);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 15));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        Panel navPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 6, 6));
        navPanel.setBackground(new Color(45, 55, 72));

        btnNavMembers = createStyledButton("Members", new Color(66, 153, 225));
        btnNavBooks = createStyledButton("Books", new Color(66, 153, 225));
        btnNavCirculation = createStyledButton("Issue/Return", new Color(66, 153, 225));
        btnNavReservations = createStyledButton("Reservations", new Color(66, 153, 225));
        btnNavNotifications = createStyledButton("Notifications", new Color(66, 153, 225));
        btnNavReports = createStyledButton("Reports", new Color(66, 153, 225));
        btnNavBackup = createStyledButton("Backup/Restore", new Color(66, 153, 225));
        btnNavThreading = createStyledButton("Multithreading", new Color(237, 137, 54));

        navPanel.add(btnNavMembers);
        navPanel.add(btnNavBooks);
        navPanel.add(btnNavCirculation);
        navPanel.add(btnNavReservations);
        navPanel.add(btnNavNotifications);
        navPanel.add(btnNavReports);
        navPanel.add(btnNavBackup);
        navPanel.add(btnNavThreading);
        topPanel.add(navPanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);

        // Center: Card Layout Container
        cardLayout = new CardLayout();
        contentCardsPanel = new Panel(cardLayout);

        contentCardsPanel.add(createMembersPanel(), "MEMBERS");
        contentCardsPanel.add(createBooksPanel(), "BOOKS");
        contentCardsPanel.add(createCirculationPanel(), "CIRCULATION");
        contentCardsPanel.add(createReservationsPanel(), "RESERVATIONS");
        contentCardsPanel.add(createNotificationsPanel(), "NOTIFICATIONS");
        contentCardsPanel.add(createReportsPanel(), "REPORTS");
        contentCardsPanel.add(createBackupPanel(), "BACKUP");
        contentCardsPanel.add(createThreadingPanel(), "THREADING");

        add(contentCardsPanel, BorderLayout.CENTER);

        // Bottom Status Bar
        Panel statusPanel = new Panel(new FlowLayout(FlowLayout.LEFT));
        statusPanel.setBackground(new Color(226, 232, 240));
        statusBarLabel = new Label("System Ready. Connected to In-Memory & Database Service Architecture.");
        statusBarLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
        statusBarLabel.setForeground(new Color(45, 55, 72));
        statusPanel.add(statusBarLabel);
        add(statusPanel, BorderLayout.SOUTH);

        // Attach AWT MenuBar if hosted inside an AWT Frame
        attachMenuBarIfInFrame();

        setStatus("Applet initialized successfully. Ready for evaluation.");
    }

    @Override
    public void start() {
        setStatus("Applet started. Background services active.");
    }

    @Override
    public void stop() {
        setStatus("Applet stopped/paused.");
    }

    @Override
    public void destroy() {
        setStatus("Applet destroyed. Resources released.");
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
    }

    // =========================================================================
    // BACKEND INITIALIZATION
    // =========================================================================

    private void initServices() {
        this.dbManager = new DatabaseManager();
        this.inventory = new Inventory();
        this.memberService = new MemberService(dbManager);
        this.bookService = new BookService(inventory, dbManager);
        this.reservationService = new ReservationService(dbManager);
        this.libraryService = new LibraryService(memberService, bookService, reservationService, inventory, dbManager);
        this.reportService = new ReportService(libraryService);
        this.threadCoordinator = new ThreadCoordinator(inventory, libraryService);
    }

    // =========================================================================
    // AWT MENU BAR IMPLEMENTATION
    // =========================================================================

    private void attachMenuBarIfInFrame() {
        Component parent = getParent();
        while (parent != null && !(parent instanceof Frame)) {
            parent = parent.getParent();
        }
        if (parent instanceof Frame) {
            Frame frame = (Frame) parent;
            MenuBar menuBar = new MenuBar();

            // File Menu
            Menu menuFile = new Menu("File");
            MenuItem itemBackup = new MenuItem("Backup State");
            itemBackup.setActionCommand("MENU_BACKUP");
            MenuItem itemRestore = new MenuItem("Restore State");
            itemRestore.setActionCommand("MENU_RESTORE");
            MenuItem itemExit = new MenuItem("Exit");
            itemExit.setActionCommand("MENU_EXIT");
            itemBackup.addActionListener(this);
            itemRestore.addActionListener(this);
            itemExit.addActionListener(this);
            menuFile.add(itemBackup);
            menuFile.add(itemRestore);
            menuFile.addSeparator();
            menuFile.add(itemExit);

            // Members Menu
            Menu menuMembers = new Menu("Members");
            MenuItem itemRegMember = new MenuItem("Register Member");
            itemRegMember.setActionCommand("MENU_MEMBERS");
            MenuItem itemSearchMember = new MenuItem("Search Member");
            itemSearchMember.setActionCommand("MENU_MEMBERS");
            MenuItem itemListMembers = new MenuItem("List All Members");
            itemListMembers.setActionCommand("MENU_MEMBERS");
            itemRegMember.addActionListener(this);
            itemSearchMember.addActionListener(this);
            itemListMembers.addActionListener(this);
            menuMembers.add(itemRegMember);
            menuMembers.add(itemSearchMember);
            menuMembers.add(itemListMembers);

            // Books Menu
            Menu menuBooks = new Menu("Books");
            MenuItem itemAddBook = new MenuItem("Add Book");
            itemAddBook.setActionCommand("MENU_BOOKS");
            MenuItem itemSearchBook = new MenuItem("Search Book");
            itemSearchBook.setActionCommand("MENU_BOOKS");
            MenuItem itemListBooks = new MenuItem("List All Books");
            itemListBooks.setActionCommand("MENU_BOOKS");
            itemAddBook.addActionListener(this);
            itemSearchBook.addActionListener(this);
            itemListBooks.addActionListener(this);
            menuBooks.add(itemAddBook);
            menuBooks.add(itemSearchBook);
            menuBooks.add(itemListBooks);

            // Circulation Menu
            Menu menuCirc = new Menu("Circulation");
            MenuItem itemIssue = new MenuItem("Issue Book");
            itemIssue.setActionCommand("MENU_CIRCULATION");
            MenuItem itemReturn = new MenuItem("Return Book");
            itemReturn.setActionCommand("MENU_CIRCULATION");
            MenuItem itemResWaitlist = new MenuItem("View Reservations");
            itemResWaitlist.setActionCommand("MENU_RESERVATIONS");
            itemIssue.addActionListener(this);
            itemReturn.addActionListener(this);
            itemResWaitlist.addActionListener(this);
            menuCirc.add(itemIssue);
            menuCirc.add(itemReturn);
            menuCirc.add(itemResWaitlist);

            // Reports Menu
            Menu menuReports = new Menu("Reports");
            MenuItem itemCircReport = new MenuItem("Circulation Report");
            itemCircReport.setActionCommand("MENU_CIRC_REPORT");
            MenuItem itemInvReport = new MenuItem("Inventory Utilization");
            itemInvReport.setActionCommand("MENU_INV_REPORT");
            MenuItem itemFineReport = new MenuItem("Fine Report");
            itemFineReport.setActionCommand("MENU_FINE_REPORT");
            MenuItem itemExportReport = new MenuItem("Export Report to TXT");
            itemExportReport.setActionCommand("MENU_EXPORT_REPORT");
            itemCircReport.addActionListener(this);
            itemInvReport.addActionListener(this);
            itemFineReport.addActionListener(this);
            itemExportReport.addActionListener(this);
            menuReports.add(itemCircReport);
            menuReports.add(itemInvReport);
            menuReports.add(itemFineReport);
            menuReports.addSeparator();
            menuReports.add(itemExportReport);

            // System Menu
            Menu menuSystem = new Menu("System");
            MenuItem itemNotifs = new MenuItem("Notifications");
            itemNotifs.setActionCommand("MENU_NOTIFICATIONS");
            MenuItem itemThreadDemo = new MenuItem("Multithreading Demo");
            itemThreadDemo.setActionCommand("MENU_THREADING");
            itemNotifs.addActionListener(this);
            itemThreadDemo.addActionListener(this);
            menuSystem.add(itemNotifs);
            menuSystem.add(itemThreadDemo);

            menuBar.add(menuFile);
            menuBar.add(menuMembers);
            menuBar.add(menuBooks);
            menuBar.add(menuCirc);
            menuBar.add(menuReports);
            menuBar.add(menuSystem);

            frame.setMenuBar(menuBar);
        }
    }

    // =========================================================================
    // GUI PANELS CREATION (AWT ONLY)
    // =========================================================================

    private Panel createMembersPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel formPanel = new Panel(new GridLayout(4, 2, 6, 6));
        formPanel.add(new Label("Member ID (Integer):"));
        txtMemberId = new TextField(10);
        formPanel.add(txtMemberId);

        formPanel.add(new Label("Full Name:"));
        txtMemberName = new TextField(20);
        formPanel.add(txtMemberName);

        formPanel.add(new Label("Email Address:"));
        txtMemberEmail = new TextField(20);
        formPanel.add(txtMemberEmail);

        formPanel.add(new Label("Member Type (Polymorphic):"));
        choiceMemberType = new Choice();
        choiceMemberType.add("Student");
        choiceMemberType.add("Faculty");
        choiceMemberType.add("Premium");
        choiceMemberType.addItemListener(this);
        formPanel.add(choiceMemberType);

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("MEMBER MANAGEMENT (Encapsulation, Inheritance, HashMap & Iterators)", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);
        topControl.add(formPanel, BorderLayout.CENTER);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 6, 6));
        btnMemberRegister = new Button("Register");
        btnMemberUpdate = new Button("Update");
        btnMemberDelete = new Button("Delete");
        btnMemberListAll = new Button("Display All");
        txtMemberSearch = new TextField(12);
        btnMemberSearch = new Button("Search");

        btnMemberRegister.addActionListener(this);
        btnMemberUpdate.addActionListener(this);
        btnMemberDelete.addActionListener(this);
        btnMemberListAll.addActionListener(this);
        btnMemberSearch.addActionListener(this);

        btnPanel.add(btnMemberRegister);
        btnPanel.add(btnMemberUpdate);
        btnPanel.add(btnMemberDelete);
        btnPanel.add(btnMemberListAll);
        btnPanel.add(new Label("Search:"));
        btnPanel.add(txtMemberSearch);
        btnPanel.add(btnMemberSearch);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaMemberOutput = new TextArea(14, 80);
        areaMemberOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaMemberOutput.setEditable(false);
        p.add(areaMemberOutput, BorderLayout.CENTER);

        return p;
    }

    private Panel createBooksPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel formPanel = new Panel(new GridLayout(6, 2, 6, 6));
        formPanel.add(new Label("Book ID (Integer):"));
        txtBookId = new TextField(10);
        formPanel.add(txtBookId);

        formPanel.add(new Label("Title:"));
        txtBookTitle = new TextField(20);
        formPanel.add(txtBookTitle);

        formPanel.add(new Label("Author:"));
        txtBookAuthor = new TextField(20);
        formPanel.add(txtBookAuthor);

        formPanel.add(new Label("Category:"));
        txtBookCategory = new TextField(20);
        formPanel.add(txtBookCategory);

        formPanel.add(new Label("Book Type (Polymorphic):"));
        choiceBookType = new Choice();
        choiceBookType.add("Regular");
        choiceBookType.add("Reference");
        choiceBookType.add("E-Book");
        choiceBookType.addItemListener(this);
        formPanel.add(choiceBookType);

        formPanel.add(new Label("Total Copies:"));
        txtBookCopies = new TextField(10);
        formPanel.add(txtBookCopies);

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("BOOK MANAGEMENT (ArrayList<Book>, HashSet<Category>, ListIterator)", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);
        topControl.add(formPanel, BorderLayout.CENTER);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 6, 6));
        btnBookAdd = new Button("Add Book");
        btnBookUpdate = new Button("Update Book");
        btnBookDelete = new Button("Delete Book");
        btnBookCheckStock = new Button("Check Stock");
        btnBookListAll = new Button("Display All Books");
        txtBookSearch = new TextField(12);
        btnBookSearch = new Button("Search");

        btnBookAdd.addActionListener(this);
        btnBookUpdate.addActionListener(this);
        btnBookDelete.addActionListener(this);
        btnBookCheckStock.addActionListener(this);
        btnBookListAll.addActionListener(this);
        btnBookSearch.addActionListener(this);

        btnPanel.add(btnBookAdd);
        btnPanel.add(btnBookUpdate);
        btnPanel.add(btnBookDelete);
        btnPanel.add(btnBookCheckStock);
        btnPanel.add(btnBookListAll);
        btnPanel.add(new Label("Search:"));
        btnPanel.add(txtBookSearch);
        btnPanel.add(btnBookSearch);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaBookOutput = new TextArea(14, 80);
        areaBookOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaBookOutput.setEditable(false);
        p.add(areaBookOutput, BorderLayout.CENTER);

        return p;
    }

    private Panel createCirculationPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel formPanel = new Panel(new GridLayout(2, 2, 6, 6));
        formPanel.add(new Label("Member ID:"));
        txtCircMemberId = new TextField(10);
        formPanel.add(txtCircMemberId);

        formPanel.add(new Label("Book ID:"));
        txtCircBookId = new TextField(10);
        formPanel.add(txtCircBookId);

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("CIRCULATION (Issue & Return Transactions, Fine Calculation, Shared Inventory)", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);
        topControl.add(formPanel, BorderLayout.CENTER);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        btnCircIssue = new Button("Issue Book");
        btnCircReturn = new Button("Return Book");
        btnCircListActive = new Button("Display Circulation Log");

        btnCircIssue.addActionListener(this);
        btnCircReturn.addActionListener(this);
        btnCircListActive.addActionListener(this);

        btnPanel.add(btnCircIssue);
        btnPanel.add(btnCircReturn);
        btnPanel.add(btnCircListActive);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaCircOutput = new TextArea(14, 80);
        areaCircOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaCircOutput.setEditable(false);
        p.add(areaCircOutput, BorderLayout.CENTER);

        return p;
    }

    private Panel createReservationsPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel formPanel = new Panel(new GridLayout(3, 2, 6, 6));
        formPanel.add(new Label("Member ID:"));
        txtResMemberId = new TextField(10);
        formPanel.add(txtResMemberId);

        formPanel.add(new Label("Book ID (When Stock = 0):"));
        txtResBookId = new TextField(10);
        formPanel.add(txtResBookId);

        formPanel.add(new Label("Reservation ID (For Cancellation):"));
        txtResCancelId = new TextField(10);
        formPanel.add(txtResCancelId);

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("BOOK RESERVATION WAITLIST (FIFO Queue & Duplicate Reservation Prevention)", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);
        topControl.add(formPanel, BorderLayout.CENTER);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        btnResCreate = new Button("Place Reservation");
        btnResCancel = new Button("Cancel Reservation");
        btnResListWaitlist = new Button("View Waitlist");

        btnResCreate.addActionListener(this);
        btnResCancel.addActionListener(this);
        btnResListWaitlist.addActionListener(this);

        btnPanel.add(btnResCreate);
        btnPanel.add(btnResCancel);
        btnPanel.add(btnResListWaitlist);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaResOutput = new TextArea(14, 80);
        areaResOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaResOutput.setEditable(false);
        p.add(areaResOutput, BorderLayout.CENTER);

        return p;
    }

    private Panel createNotificationsPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("NOTIFICATION SYSTEM (Due Reminders, Overdue Fines & Waitlist Alerts)", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        btnNotifScanOverdue = new Button("Scan Overdue Records");
        btnNotifListAll = new Button("Display All Notifications");

        btnNotifScanOverdue.addActionListener(this);
        btnNotifListAll.addActionListener(this);

        btnPanel.add(btnNotifScanOverdue);
        btnPanel.add(btnNotifListAll);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaNotifOutput = new TextArea(14, 80);
        areaNotifOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaNotifOutput.setEditable(false);
        p.add(areaNotifOutput, BorderLayout.CENTER);

        return p;
    }

    private Panel createReportsPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("ANALYTICS & REPORTS (Circulation, Inventory Utilization %, Fines & Character Stream Export)", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 6, 6));
        btnReportCirculation = new Button("Circulation Report");
        btnReportInventory = new Button("Inventory Utilization");
        btnReportFines = new Button("Fine Report");
        btnReportComprehensive = new Button("Full Audit Report");
        btnReportExport = new Button("Export to reports/library_report.txt");

        btnReportCirculation.addActionListener(this);
        btnReportInventory.addActionListener(this);
        btnReportFines.addActionListener(this);
        btnReportComprehensive.addActionListener(this);
        btnReportExport.addActionListener(this);

        btnPanel.add(btnReportCirculation);
        btnPanel.add(btnReportInventory);
        btnPanel.add(btnReportFines);
        btnPanel.add(btnReportComprehensive);
        btnPanel.add(btnReportExport);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaReportOutput = new TextArea(14, 80);
        areaReportOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaReportOutput.setEditable(false);
        p.add(areaReportOutput, BorderLayout.CENTER);

        return p;
    }

    private Panel createBackupPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("BACKUP & RESTORE (Java Object Serialization & SHA-256 Checksum)", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        btnBackupSave = new Button("Backup (Serialize to .ser)");
        btnBackupRestore = new Button("Restore (Deserialize from .ser)");
        btnBackupVerifyHash = new Button("Verify SHA-256 Integrity");

        btnBackupSave.addActionListener(this);
        btnBackupRestore.addActionListener(this);
        btnBackupVerifyHash.addActionListener(this);

        btnPanel.add(btnBackupSave);
        btnPanel.add(btnBackupRestore);
        btnPanel.add(btnBackupVerifyHash);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaBackupOutput = new TextArea(14, 80);
        areaBackupOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaBackupOutput.setEditable(false);
        p.add(areaBackupOutput, BorderLayout.CENTER);

        return p;
    }

    private Panel createThreadingPanel() {
        Panel p = new Panel(new BorderLayout(8, 8));
        p.setBackground(new Color(247, 250, 252));

        Panel topControl = new Panel(new BorderLayout(5, 5));
        Label header = new Label("MULTITHREADING DEMONSTRATION (Priorities, Synchronization, wait() / notifyAll())", Label.LEFT);
        header.setFont(new Font("SansSerif", Font.BOLD, 13));
        topControl.add(header, BorderLayout.NORTH);

        Panel btnPanel = new Panel(new FlowLayout(FlowLayout.CENTER, 8, 6));
        btnThreadRunDemo = new Button("Run Multithreading Demo");
        btnThreadRunDemo.addActionListener(this);
        btnPanel.add(btnThreadRunDemo);
        topControl.add(btnPanel, BorderLayout.SOUTH);

        p.add(topControl, BorderLayout.NORTH);

        areaThreadOutput = new TextArea(14, 80);
        areaThreadOutput.setFont(new Font("Monospaced", Font.PLAIN, 12));
        areaThreadOutput.setEditable(false);
        p.add(areaThreadOutput, BorderLayout.CENTER);

        return p;
    }

    private Button createStyledButton(String text, Color bg) {
        Button b = new Button(text);
        b.setBackground(bg);
        b.addActionListener(this);
        return b;
    }

    private void setStatus(String message) {
        if (statusBarLabel != null) {
            statusBarLabel.setText("Status: " + message);
        }
    }

    // =========================================================================
    // DELEGATION EVENT MODEL - ACTION LISTENER & ITEM LISTENER
    // =========================================================================

    @Override
    public void itemStateChanged(ItemEvent e) {
        // Demonstrates ItemListener for Choice component changes
        if (e.getSource() == choiceMemberType) {
            String selected = choiceMemberType.getSelectedItem();
            setStatus("Selected Member Type: " + selected + " (Demonstrates runtime polymorphism)");
        } else if (e.getSource() == choiceBookType) {
            String selected = choiceBookType.getSelectedItem();
            setStatus("Selected Book Category: " + selected);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object src = e.getSource();
        String cmd = e.getActionCommand();

        // 1. Navigation Actions (Top Buttons and Menu items)
        if (src == btnNavMembers || "MENU_MEMBERS".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "MEMBERS");
            setStatus("Switched to Member Management.");
        } else if (src == btnNavBooks || "MENU_BOOKS".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "BOOKS");
            setStatus("Switched to Book Management.");
        } else if (src == btnNavCirculation || "MENU_CIRCULATION".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "CIRCULATION");
            setStatus("Switched to Circulation (Issue/Return).");
        } else if (src == btnNavReservations || "MENU_RESERVATIONS".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "RESERVATIONS");
            setStatus("Switched to Book Reservations.");
        } else if (src == btnNavNotifications || "MENU_NOTIFICATIONS".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "NOTIFICATIONS");
            setStatus("Switched to Notifications.");
        } else if (src == btnNavReports) {
            cardLayout.show(contentCardsPanel, "REPORTS");
            setStatus("Switched to Reports & Analytics.");
        } else if (src == btnNavBackup) {
            cardLayout.show(contentCardsPanel, "BACKUP");
            setStatus("Switched to Backup & Serialization.");
        } else if (src == btnNavThreading || "MENU_THREADING".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "THREADING");
            setStatus("Switched to Multithreading Demonstration.");
        } else if ("MENU_EXIT".equals(cmd) || "Exit".equals(cmd)) {
            setStatus("Exit requested.");
            System.exit(0);
        }

        // 2. Member Operations
        else if (src == btnMemberRegister) {
            handleMemberRegister();
        } else if (src == btnMemberSearch) {
            handleMemberSearch();
        } else if (src == btnMemberUpdate) {
            handleMemberUpdate();
        } else if (src == btnMemberDelete) {
            handleMemberDelete();
        } else if (src == btnMemberListAll) {
            handleMemberListAll();
        }

        // 3. Book Operations
        else if (src == btnBookAdd) {
            handleBookAdd();
        } else if (src == btnBookSearch) {
            handleBookSearch();
        } else if (src == btnBookUpdate) {
            handleBookUpdate();
        } else if (src == btnBookDelete) {
            handleBookDelete();
        } else if (src == btnBookCheckStock) {
            handleBookCheckStock();
        } else if (src == btnBookListAll) {
            handleBookListAll();
        }

        // 4. Circulation Operations
        else if (src == btnCircIssue) {
            handleCircIssue();
        } else if (src == btnCircReturn) {
            handleCircReturn();
        } else if (src == btnCircListActive) {
            handleCircListActive();
        }

        // 5. Reservation Operations
        else if (src == btnResCreate) {
            handleResCreate();
        } else if (src == btnResCancel) {
            handleResCancel();
        } else if (src == btnResListWaitlist) {
            handleResListWaitlist();
        }

        // 6. Notification Operations
        else if (src == btnNotifScanOverdue) {
            handleNotifScanOverdue();
        } else if (src == btnNotifListAll) {
            handleNotifListAll();
        }

        // 7. Report Operations
        else if (src == btnReportCirculation || "MENU_CIRC_REPORT".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "REPORTS");
            areaReportOutput.setText(reportService.generateCirculationReport());
            setStatus("Circulation report generated.");
        } else if (src == btnReportInventory || "MENU_INV_REPORT".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "REPORTS");
            areaReportOutput.setText(reportService.generateInventoryReport());
            setStatus("Inventory utilization report generated.");
        } else if (src == btnReportFines || "MENU_FINE_REPORT".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "REPORTS");
            areaReportOutput.setText(reportService.generateFineReport());
            setStatus("Overdue fine report generated.");
        } else if (src == btnReportComprehensive) {
            cardLayout.show(contentCardsPanel, "REPORTS");
            areaReportOutput.setText(reportService.generateComprehensiveAuditReport());
            setStatus("Comprehensive library audit report generated.");
        } else if (src == btnReportExport || "MENU_EXPORT_REPORT".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "REPORTS");
            handleReportExport();
        }

        // 8. Backup Operations
        else if (src == btnBackupSave || "MENU_BACKUP".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "BACKUP");
            handleBackupSave();
        } else if (src == btnBackupRestore || "MENU_RESTORE".equals(cmd)) {
            cardLayout.show(contentCardsPanel, "BACKUP");
            handleBackupRestore();
        } else if (src == btnBackupVerifyHash) {
            cardLayout.show(contentCardsPanel, "BACKUP");
            handleBackupVerifyHash();
        }

        // 9. Multithreading Operations
        else if (src == btnThreadRunDemo) {
            handleThreadingDemo();
        }
    }

    // =========================================================================
    // EVENT HANDLERS FOR BUSINESS WORKFLOWS
    // =========================================================================

    private void handleMemberRegister() {
        try {
            int id = InputValidator.validatePositiveInt(txtMemberId.getText(), "Member ID");
            String name = InputValidator.validateNonEmptyString(txtMemberName.getText(), "Member Name");
            String email = InputValidator.validateEmail(txtMemberEmail.getText());
            String type = choiceMemberType.getSelectedItem();
            if (type == null) type = "Student";

            Member m = memberService.registerMember(id, name, email, type);
            areaMemberOutput.setText("SUCCESS: Registered " + m.getMemberType() + " Member #" + id + "\n\n" + m.toString() +
                    "\nBorrow Limit: " + m.getBorrowLimit() + " books | Fine Rate: ₹" + (m.calculateFine(1)) + "/day");
            setStatus("Member #" + id + " registered successfully.");
            clearMemberFields();
        } catch (InvalidMemberException | InvalidInputException | SQLException e) {
            areaMemberOutput.setText("REGISTRATION ERROR: " + e.getMessage());
            setStatus("Registration failed: " + e.getMessage());
        } catch (Throwable t) {
            areaMemberOutput.setText("UNEXPECTED ERROR: " + t.getMessage());
            setStatus("Error: " + t.getMessage());
        }
    }

    private void handleMemberSearch() {
        String q = txtMemberSearch.getText();
        List<Member> results = memberService.searchMembers(q);
        StringBuilder sb = new StringBuilder("SEARCH RESULTS (" + results.size() + " found):\n");
        sb.append("--------------------------------------------------------------------------------\n");
        for (Member m : results) {
            sb.append(m.toString()).append("\n");
        }
        areaMemberOutput.setText(sb.toString());
        setStatus("Search completed. Found " + results.size() + " member(s).");
    }

    private void handleMemberUpdate() {
        try {
            int id = InputValidator.validatePositiveInt(txtMemberId.getText(), "Member ID");
            String name = txtMemberName.getText();
            String email = txtMemberEmail.getText();
            String type = choiceMemberType.getSelectedItem();

            memberService.updateMember(id, name, email, type);
            Member updated = memberService.getMemberById(id);
            areaMemberOutput.setText("SUCCESS: Updated Member #" + id + "\n\n" + updated.toString());
            setStatus("Member #" + id + " updated successfully.");
        } catch (InvalidMemberException | InvalidInputException | SQLException e) {
            areaMemberOutput.setText("ERROR: " + e.getMessage());
            setStatus("Update failed: " + e.getMessage());
        } catch (Throwable t) {
            areaMemberOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleMemberDelete() {
        try {
            int id = InputValidator.validatePositiveInt(txtMemberId.getText(), "Member ID");
            memberService.deleteMember(id);
            areaMemberOutput.setText("SUCCESS: Deleted Member #" + id);
            setStatus("Member #" + id + " deleted.");
            clearMemberFields();
        } catch (InvalidMemberException | InvalidInputException | SQLException e) {
            areaMemberOutput.setText("ERROR: " + e.getMessage());
            setStatus("Deletion failed: " + e.getMessage());
        } catch (Throwable t) {
            areaMemberOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleMemberListAll() {
        List<Member> all = memberService.searchMembers("");
        StringBuilder sb = new StringBuilder("ALL REGISTERED MEMBERS (" + all.size() + " total):\n");
        sb.append("================================================================================\n");
        for (Member m : all) {
            sb.append(m.toString()).append("\n");
        }
        areaMemberOutput.setText(sb.toString());
        setStatus("Displaying all " + all.size() + " members.");
    }

    private void clearMemberFields() {
        txtMemberId.setText("");
        txtMemberName.setText("");
        txtMemberEmail.setText("");
    }

    private void handleBookAdd() {
        try {
            int id = InputValidator.validatePositiveInt(txtBookId.getText(), "Book ID");
            String title = InputValidator.validateNonEmptyString(txtBookTitle.getText(), "Book Title");
            String author = InputValidator.validateNonEmptyString(txtBookAuthor.getText(), "Author");
            String cat = InputValidator.validateNonEmptyString(txtBookCategory.getText(), "Category");
            String type = choiceBookType.getSelectedItem();
            if (type == null) type = "Regular";
            int copies = InputValidator.validatePositiveInt(txtBookCopies.getText(), "Total Copies");

            Book b = bookService.addBook(id, title, author, cat, type, copies);
            areaBookOutput.setText("SUCCESS: Added " + b.getBookType() + " Book #" + id + "\n\n" + b.toString() +
                    "\nLendable: " + b.isLendable() + " | Default Loan: " + b.getDefaultLoanDays() + " days");
            setStatus("Book #" + id + " added to catalog.");
            clearBookFields();
        } catch (InvalidInputException | SQLException e) {
            areaBookOutput.setText("ADD BOOK ERROR:\n" + e.getMessage());
            setStatus("Add Book failed: " + e.getMessage());
        } catch (Throwable t) {
            areaBookOutput.setText("UNEXPECTED ERROR:\n" + t.getMessage());
            setStatus("Error: " + t.getMessage());
        }
    }

    private void handleBookSearch() {
        String q = txtBookSearch.getText();
        List<Book> results = bookService.searchBooks(q);
        StringBuilder sb = new StringBuilder("SEARCH RESULTS (" + results.size() + " books found):\n");
        sb.append("================================================================================\n");
        for (Book b : results) {
            sb.append(b.toString()).append("\n");
        }
        areaBookOutput.setText(sb.toString());
        setStatus("Search completed. Found " + results.size() + " book(s).");
    }

    private void handleBookUpdate() {
        try {
            int id = InputValidator.validatePositiveInt(txtBookId.getText(), "Book ID");
            String title = InputValidator.validateNonEmptyString(txtBookTitle.getText(), "Book Title");
            String author = InputValidator.validateNonEmptyString(txtBookAuthor.getText(), "Author");
            String cat = InputValidator.validateNonEmptyString(txtBookCategory.getText(), "Category");
            String type = choiceBookType.getSelectedItem();
            if (type == null) type = "Regular";
            int copies = InputValidator.validatePositiveInt(txtBookCopies.getText(), "Total Copies");

            bookService.updateBook(id, title, author, cat, type, copies);
            Book updated = bookService.getBookById(id);
            areaBookOutput.setText("SUCCESS: Updated Book #" + id + " via ListIterator\n\n" + updated.toString());
            setStatus("Book #" + id + " updated successfully.");
        } catch (InvalidInputException | BookNotFoundException | SQLException e) {
            areaBookOutput.setText("UPDATE ERROR:\n" + e.getMessage());
            setStatus("Update Book failed: " + e.getMessage());
        } catch (Throwable t) {
            areaBookOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleBookDelete() {
        try {
            int id = InputValidator.validatePositiveInt(txtBookId.getText(), "Book ID");
            bookService.deleteBook(id);
            areaBookOutput.setText("SUCCESS: Deleted Book #" + id);
            setStatus("Book #" + id + " deleted.");
            clearBookFields();
        } catch (BookNotFoundException | InvalidInputException | SQLException e) {
            areaBookOutput.setText("DELETE ERROR:\n" + e.getMessage());
            setStatus("Deletion failed: " + e.getMessage());
        } catch (Throwable t) {
            areaBookOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleBookCheckStock() {
        try {
            int id = InputValidator.validatePositiveInt(txtBookId.getText(), "Book ID");
            Book b = bookService.getBookById(id);
            int avail = inventory.getAvailableCopies(id);
            int total = inventory.getTotalCopies(id);
            areaBookOutput.setText("INVENTORY STATUS for Book #" + id + " ('" + b.getTitle() + "'):\n\n" +
                    "Title            : " + b.getTitle() + "\n" +
                    "Category         : " + b.getCategory() + "\n" +
                    "Book Type        : " + b.getBookType() + "\n" +
                    "Available Copies : " + avail + "\n" +
                    "Total Copies     : " + total + "\n" +
                    "Currently Issued : " + (total - avail) + "\n" +
                    "Status           : " + (avail > 0 ? "AVAILABLE FOR CHECKOUT" : "OUT OF STOCK - RESERVATION ALLOWED"));
            setStatus("Stock check complete for Book #" + id);
        } catch (BookNotFoundException | InvalidInputException e) {
            areaBookOutput.setText("STOCK CHECK ERROR:\n" + e.getMessage());
            setStatus("Check failed: " + e.getMessage());
        } catch (Throwable t) {
            areaBookOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleBookListAll() {
        List<Book> all = bookService.getAllBooks();
        StringBuilder sb = new StringBuilder("ALL BOOKS IN CATALOG (" + all.size() + " titles):\n");
        sb.append("================================================================================\n");
        for (Book b : all) {
            sb.append(b.toString()).append("\n");
        }
        sb.append("\nUnique Categories (HashSet): ").append(bookService.getUniqueCategories());
        areaBookOutput.setText(sb.toString());
        setStatus("Displaying all " + all.size() + " books.");
    }

    private void clearBookFields() {
        txtBookId.setText("");
        txtBookTitle.setText("");
        txtBookAuthor.setText("");
        txtBookCategory.setText("");
        txtBookCopies.setText("");
    }

    private void handleCircIssue() {
        try {
            int memberId = InputValidator.validatePositiveInt(txtCircMemberId.getText(), "Member ID");
            int bookId = InputValidator.validatePositiveInt(txtCircBookId.getText(), "Book ID");

            IssuedBook issue = libraryService.issueBook(memberId, bookId);
            Member m = memberService.getMemberById(memberId);
            Book b = bookService.getBookById(bookId);

            areaCircOutput.setText("SUCCESS: Book Issued!\n\n" +
                    "Issue Record ID  : #" + issue.getIssueId() + "\n" +
                    "Borrower         : " + m.getName() + " (" + m.getMemberType() + ")\n" +
                    "Book Title       : " + b.getTitle() + " (ID: " + b.getBookId() + ")\n" +
                    "Borrow Limit Used: " + m.getCurrentIssuedCount() + "/" + m.getBorrowLimit() + "\n" +
                    "Due Date         : " + issue.getDueDate() + "\n" +
                    "Remaining Stock  : " + b.getAvailableCopies() + " copies");
            setStatus("Book #" + bookId + " successfully issued to Member #" + memberId);
        } catch (InvalidMemberException | BookNotFoundException | BookUnavailableException | BorrowLimitExceededException | InvalidInputException | SQLException e) {
            areaCircOutput.setText("CHECKOUT REJECTED:\n" + e.getMessage());
            setStatus("Issue failed: " + e.getMessage());
        } catch (Throwable t) {
            areaCircOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleCircReturn() {
        try {
            int memberId = InputValidator.validatePositiveInt(txtCircMemberId.getText(), "Member ID");
            int bookId = InputValidator.validatePositiveInt(txtCircBookId.getText(), "Book ID");

            String returnSummary = libraryService.returnBook(memberId, bookId);
            areaCircOutput.setText("RETURN PROCESSED:\n\n" + returnSummary);
            setStatus("Book #" + bookId + " returned successfully.");
        } catch (InvalidMemberException | BookNotFoundException | InvalidInputException | SQLException e) {
            areaCircOutput.setText("RETURN FAILED:\n" + e.getMessage());
            setStatus("Return failed: " + e.getMessage());
        } catch (Throwable t) {
            areaCircOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleCircListActive() {
        List<IssuedBook> list = libraryService.getIssuedBooks();
        StringBuilder sb = new StringBuilder("CIRCULATION CHECKOUT RECORDS (" + list.size() + " total):\n");
        sb.append("================================================================================\n");
        for (IssuedBook ib : list) {
            sb.append(ib.toString()).append("\n");
        }
        areaCircOutput.setText(sb.toString());
        setStatus("Displaying circulation log.");
    }

    private void handleResCreate() {
        try {
            int memberId = InputValidator.validatePositiveInt(txtResMemberId.getText(), "Member ID");
            int bookId = InputValidator.validatePositiveInt(txtResBookId.getText(), "Book ID");

            // Validate member and book existence
            memberService.getMemberById(memberId);
            Book b = bookService.getBookById(bookId);

            if (b.getAvailableCopies() > 0) {
                areaResOutput.setText("NOTICE: Book #" + bookId + " is currently in stock (" + b.getAvailableCopies() +
                        " copies available). You can issue it immediately rather than reserving.");
                setStatus("Reservation unnecessary: copies available.");
                return;
            }

            Reservation res = reservationService.reserveBook(memberId, bookId);
            areaResOutput.setText("SUCCESS: Reservation Placed in Waitlist!\n\n" + res.toString());
            setStatus("Reservation #" + res.getReservationId() + " created.");
        } catch (InvalidMemberException | BookNotFoundException | DuplicateReservationException | InvalidInputException | SQLException e) {
            areaResOutput.setText("RESERVATION REJECTED:\n" + e.getMessage());
            setStatus("Reservation error: " + e.getMessage());
        } catch (Throwable t) {
            areaResOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleResCancel() {
        try {
            int resId = InputValidator.validatePositiveInt(txtResCancelId.getText(), "Reservation ID");
            reservationService.cancelReservation(resId);
            areaResOutput.setText("SUCCESS: Cancelled Reservation #" + resId);
            setStatus("Reservation #" + resId + " cancelled.");
        } catch (InvalidInputException | SQLException e) {
            areaResOutput.setText("ERROR: " + e.getMessage());
            setStatus("Cancellation failed: " + e.getMessage());
        } catch (Throwable t) {
            areaResOutput.setText("ERROR: " + t.getMessage());
        }
    }

    private void handleResListWaitlist() {
        List<Reservation> list = reservationService.getAllReservations();
        StringBuilder sb = new StringBuilder("RESERVATION WAITLIST RECORDS (" + list.size() + " total):\n");
        sb.append("================================================================================\n");
        for (Reservation r : list) {
            sb.append(r.toString()).append("\n");
        }
        areaResOutput.setText(sb.toString());
        setStatus("Displaying reservation waitlist.");
    }

    private void handleNotifScanOverdue() {
        List<Notification> newNotifs = libraryService.scanAndGenerateOverdueNotifications();
        StringBuilder sb = new StringBuilder("SCAN COMPLETE: Generated " + newNotifs.size() + " new overdue notices.\n\n");
        for (Notification n : newNotifs) {
            sb.append(n.formatNotification()).append("\n");
        }
        areaNotifOutput.setText(sb.toString());
        setStatus("Overdue scanner generated " + newNotifs.size() + " notice(s).");
    }

    private void handleNotifListAll() {
        List<Notification> list = libraryService.getNotifications();
        StringBuilder sb = new StringBuilder("ALL SYSTEM NOTIFICATIONS (" + list.size() + " total):\n");
        sb.append("================================================================================\n");
        for (Notification n : list) {
            sb.append(n.formatNotification()).append("\n");
        }
        areaNotifOutput.setText(sb.toString());
        setStatus("Displaying all notifications.");
    }

    private void handleReportExport() {
        try {
            String path = "reports/library_report.txt";
            reportService.exportReportToFile(path);
            String content = FileReportWriter.readReport(path);
            areaReportOutput.setText("REPORT EXPORTED SUCCESSFULLY TO: " + new File(path).getAbsolutePath() + "\n\n" + content);
            setStatus("Report exported via Character Streams to " + path);
        } catch (IOException e) {
            areaReportOutput.setText("EXPORT ERROR: " + e.getMessage());
            setStatus("Failed to export report: " + e.getMessage());
        }
    }

    private void handleBackupSave() {
        try {
            String path = "backups/library_backup.ser";
            BackupManager.LibraryState state = new BackupManager.LibraryState(
                    memberService.getMemberMapSnapshot(),
                    bookService.getAllBooks(),
                    reservationService.getAllReservations(),
                    libraryService.getIssuedBooks(),
                    inventory,
                    libraryService.getNotifications()
            );
            BackupManager.saveBackup(state, path);
            String hash = HashUtil.computeFileChecksum(new File(path));

            areaBackupOutput.setText("SUCCESS: Library State Serialized to: " + new File(path).getAbsolutePath() + "\n\n" +
                    "Members Serialized      : " + state.getMembers().size() + "\n" +
                    "Books Serialized        : " + state.getBooks().size() + "\n" +
                    "Reservations Serialized : " + state.getReservations().size() + "\n" +
                    "Checkouts Serialized    : " + state.getIssuedBooks().size() + "\n" +
                    "Backup Timestamp        : " + state.getTimestamp() + "\n" +
                    "SHA-256 Checksum        : " + hash);
            setStatus("Backup state serialized successfully to " + path);
        } catch (IOException e) {
            areaBackupOutput.setText("BACKUP ERROR: " + e.getMessage());
            setStatus("Backup failed: " + e.getMessage());
        }
    }

    private void handleBackupRestore() {
        try {
            String path = "backups/library_backup.ser";
            BackupManager.LibraryState state = BackupManager.loadBackup(path);

            areaBackupOutput.setText("SUCCESS: Deserialized Library State from: " + new File(path).getAbsolutePath() + "\n\n" +
                    "Restored Members      : " + state.getMembers().size() + "\n" +
                    "Restored Books        : " + state.getBooks().size() + "\n" +
                    "Restored Reservations : " + state.getReservations().size() + "\n" +
                    "Restored Checkouts    : " + state.getIssuedBooks().size() + "\n" +
                    "Backup Snapshot Date  : " + state.getTimestamp() + "\n" +
                    "Integrity Checksum    : " + state.getIntegrityChecksum());
            setStatus("Backup restored successfully from " + path);
        } catch (Exception e) {
            areaBackupOutput.setText("RESTORE ERROR: " + e.getMessage());
            setStatus("Restore failed: " + e.getMessage());
        }
    }

    private void handleBackupVerifyHash() {
        try {
            String path = "backups/library_backup.ser";
            File file = new File(path);
            if (!file.exists()) {
                areaBackupOutput.setText("ERROR: Backup file does not exist yet. Please click 'Backup' first.");
                return;
            }
            String sha256 = HashUtil.computeFileChecksum(file);
            areaBackupOutput.setText("SHA-256 INTEGRITY VERIFICATION:\n\n" +
                    "File: " + file.getAbsolutePath() + "\n" +
                    "Size: " + file.length() + " bytes\n" +
                    "SHA-256 Hash Digest: " + sha256 + "\n\n" +
                    "Verified: Byte Stream integrity checked via MessageDigest SHA-256.");
            setStatus("SHA-256 hash verified: " + sha256);
        } catch (IOException e) {
            areaBackupOutput.setText("HASH ERROR: " + e.getMessage());
        }
    }

    private void handleThreadingDemo() {
        areaThreadOutput.setText("Starting multithreading, synchronization & wait/notify demo...\n");
        setStatus("Running multithreading execution test...");

        new Thread(new Runnable() {
            @Override
            public void run() {
                List<String> logs = threadCoordinator.runMultithreadingDemo();
                StringBuilder sb = new StringBuilder();
                for (String line : logs) {
                    sb.append(line).append("\n");
                }
                areaThreadOutput.setText(sb.toString());
                setStatus("Multithreading demo completed successfully.");
            }
        }).start();
    }
}
