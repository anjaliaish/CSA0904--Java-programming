import service.*;
import model.*;
import database.*;

public class TestAddBook {
    public static void main(String[] args) {
        try {
            DatabaseManager db = new DatabaseManager();
            Inventory inv = new Inventory();
            BookService bs = new BookService(inv, db);
            System.out.println("Books before: " + bs.getAllBooks().size());
            Book b = bs.addBook(101, "Test Java Book", "Author Name", "Programming", "Regular", 5);
            System.out.println("Added book: " + b);
            System.out.println("Books after: " + bs.getAllBooks().size());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
