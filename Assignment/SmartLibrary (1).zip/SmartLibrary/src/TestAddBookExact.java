import database.DatabaseManager;
import model.*;
import service.BookService;
import util.InputValidator;

public class TestAddBookExact {
    public static void main(String[] args) {
        try {
            DatabaseManager db = new DatabaseManager();
            System.out.println("Database isConnected: " + db.isConnected());
            Inventory inv = new Inventory();
            BookService bs = new BookService(inv, db);

            String txtId = "B101";
            String title = "Operating Systems";
            String author = "Silberschatz";
            String cat = "Computer Science";
            String type = "Reference";
            String copies = "5";

            int id = InputValidator.validatePositiveInt(txtId, "Book ID");
            title = InputValidator.validateNonEmptyString(title, "Book Title");
            author = InputValidator.validateNonEmptyString(author, "Author");
            cat = InputValidator.validateNonEmptyString(cat, "Category");
            int totalCopies = InputValidator.validatePositiveInt(copies, "Total Copies");

            System.out.println("Validation passed: ID=" + id + ", Title=" + title + ", Copies=" + totalCopies);

            Book b = bs.addBook(id, title, author, cat, type, totalCopies);
            System.out.println("Book successfully added: " + b);
            System.out.println("Books in DB count: " + db.getAllBooks().size());
        } catch (Exception e) {
            System.err.println("FAILED TO ADD BOOK:");
            e.printStackTrace();
        }
    }
}
