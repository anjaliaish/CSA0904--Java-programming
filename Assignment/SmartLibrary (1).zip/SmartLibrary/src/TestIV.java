import util.InputValidator;
public class TestIV {
    public static void main(String[] args) throws Exception {
        System.out.println("B101 parsed: " + InputValidator.validatePositiveInt("B101", "Book ID"));
        System.out.println("101 parsed: " + InputValidator.validatePositiveInt("101", "Book ID"));
    }
}
