import database.DatabaseManager;
import exception.*;
import model.*;
import notification.*;
import service.*;
import thread.*;
import util.*;

import java.io.File;
import java.sql.Connection;
import java.sql.Statement;
import java.util.*;

/**
 * Automated Test Suite for Smart Library Management System.
 * Executes and verifies all 40+ required rubric test cases against live database.
 */
public class TestSuite {

    private static int passedCount = 0;
    private static int failedCount = 0;

    public static void main(String[] args) {
        System.out.println("================================================================================");
        System.out.println("             RUNNING SMART LIBRARY COMPREHENSIVE TEST SUITE                     ");
        System.out.println("================================================================================");

        DatabaseManager dbManager = new DatabaseManager();
        
        // Clean up test fixture IDs (> 900) before test execution
        if (dbManager.isConnected()) {
            try (Connection conn = dbManager.getConnection();
                 Statement stmt = conn.createStatement()) {
                stmt.executeUpdate("DELETE FROM notifications WHERE member_id >= 900");
                stmt.executeUpdate("DELETE FROM issued_books WHERE member_id >= 900 OR book_id >= 900");
                stmt.executeUpdate("DELETE FROM reservations WHERE member_id >= 900 OR book_id >= 900");
                stmt.executeUpdate("DELETE FROM books WHERE book_id >= 900");
                stmt.executeUpdate("DELETE FROM members WHERE member_id >= 900");
            } catch (Exception ignored) {}
        }

        Inventory inventory = new Inventory();
        MemberService memberService = new MemberService(dbManager);
        BookService bookService = new BookService(inventory, dbManager);
        ReservationService resService = new ReservationService(dbManager);
        LibraryService libService = new LibraryService(memberService, bookService, resService, inventory, dbManager);
        ReportService reportService = new ReportService(libService);

        // =========================================================================
        // CATEGORY 1: OOP, ENCAPSULATION & POLYMORPHISM (TESTS 1 - 7)
        // =========================================================================
        System.out.println("\n--- CATEGORY 1: OOP, Encapsulation & Polymorphism ---");

        // Test 1: StudentMember Polymorphic Fine (₹2.00/day) & Borrow Limit (3)
        Member sMember = new StudentMember(901, "Test Student", "student901@test.com");
        assertEquals("Test 1: Student borrow limit", 3, sMember.getBorrowLimit());
        assertEquals("Test 1: Student fine for 5 days", 10.0, sMember.calculateFine(5), 0.001);

        // Test 2: FacultyMember Polymorphic Fine (₹1.00/day) & Borrow Limit (10)
        Member fMember = new FacultyMember(902, "Test Faculty", "faculty902@test.com");
        assertEquals("Test 2: Faculty borrow limit", 10, fMember.getBorrowLimit());
        assertEquals("Test 2: Faculty fine for 5 days", 5.0, fMember.calculateFine(5), 0.001);

        // Test 3: PremiumMember Polymorphic Fine (₹0.50/day) & Borrow Limit (15)
        Member pMember = new PremiumMember(903, "Test Premium", "premium903@test.com");
        assertEquals("Test 3: Premium borrow limit", 15, pMember.getBorrowLimit());
        assertEquals("Test 3: Premium fine for 5 days", 2.50, pMember.calculateFine(5), 0.001);

        // Test 4: RegularBook lendability (true) & default loan (14 days)
        Book regBook = new RegularBook(901, "Core Java 901", "Author A", "CS", 5, 5);
        assertTrue("Test 4: RegularBook lendable", regBook.isLendable());
        assertEquals("Test 4: RegularBook loan duration", 14, regBook.getDefaultLoanDays());

        // Test 5: ReferenceBook lendability (false) & default loan (0 days)
        Book refBook = new ReferenceBook(902, "Encyclopedia Britannica 902", "Editor B", "Reference", 2, 2);
        assertTrue("Test 5: ReferenceBook not lendable", !refBook.isLendable());
        assertEquals("Test 5: ReferenceBook loan duration", 0, refBook.getDefaultLoanDays());

        // Test 6: EBook lendability (true) & default loan (21 days)
        Book eBook = new EBook(903, "Cloud Architecture 903", "Author C", "Cloud", 10, 10);
        assertTrue("Test 6: EBook lendable", eBook.isLendable());
        assertEquals("Test 6: EBook loan duration", 21, eBook.getDefaultLoanDays());

        // Test 7: Notification Polymorphism (Due vs Overdue)
        Notification dueN = new DueNotification(901, 901, 901, "Java Basics", new Date());
        Notification overN = new OverdueNotification(902, 901, 901, "Java Basics", 3, 6.00);
        assertTrue("Test 7: DueNotification formatting", dueN.formatNotification().contains("UPCOMING DUE DATE"));
        assertTrue("Test 7: OverdueNotification formatting", overN.formatNotification().contains("OVERDUE NOTICE") && overN.formatNotification().contains("₹6.00"));

        // =========================================================================
        // CATEGORY 2: COLLECTIONS FRAMEWORK (TESTS 8 - 14)
        // =========================================================================
        System.out.println("\n--- CATEGORY 2: Collections Framework ---");

        // Test 8: HashMap<Integer, Member> Insertion & Lookup
        try {
            memberService.registerMember(910, "Alice Smith", "alice910@univ.edu", "Student");
            Member retrieved = memberService.getMemberById(910);
            assertEquals("Test 8: HashMap member lookup", "Alice Smith", retrieved.getName());
        } catch (Exception e) {
            fail("Test 8: HashMap registration failed: " + e.getMessage());
        }

        // Test 9: HashMap Duplicate ID Prevention (InvalidMemberException)
        try {
            memberService.registerMember(910, "Duplicate Alice", "alice910_dup@univ.edu", "Student");
            fail("Test 9: Expected InvalidMemberException on duplicate member ID");
        } catch (InvalidMemberException e) {
            pass("Test 9: Duplicate member ID caught successfully");
        } catch (Exception e) {
            fail("Test 9: Unexpected exception: " + e.getMessage());
        }

        // Test 10: ArrayList<Book> and HashSet<String> Unique Categories
        try {
            bookService.addBook(921, "Modern OS 921", "Tanenbaum", "DistributedSystems", "Regular", 4);
            bookService.addBook(922, "Distributed Systems 922", "Tanenbaum", "DistributedSystems", "Regular", 4);
            Set<String> categories = bookService.getUniqueCategories();
            assertTrue("Test 10: HashSet contains unique category", categories.contains("DistributedSystems"));
        } catch (Exception e) {
            fail("Test 10: Book addition failed: " + e.getMessage());
        }

        // Test 11: Iterator<Book> Search Traversal
        List<Book> searchResults = bookService.searchBooks("Tanenbaum");
        assertTrue("Test 11: Iterator book search count", searchResults.size() >= 2);

        // Test 12: ListIterator<Book> In-Place Update
        try {
            bookService.updateBook(921, "Modern Operating Systems Updated", "Tanenbaum", "DistributedSystems", "Regular", 6);
            Book updated = bookService.getBookById(921);
            assertEquals("Test 12: ListIterator update title", "Modern Operating Systems Updated", updated.getTitle());
            assertEquals("Test 12: ListIterator update copies", 6, updated.getTotalCopies());
        } catch (Exception e) {
            fail("Test 12: ListIterator update failed: " + e.getMessage());
        }

        // Test 13: Hashtable<Integer, Integer> Shared Inventory
        int availCopies = inventory.getAvailableCopies(921);
        assertEquals("Test 13: Inventory Hashtable copies check", 6, availCopies);

        // Test 14: Generics enforcement (type safety)
        ArrayList<Book> genericBooks = (ArrayList<Book>) bookService.getAllBooks();
        assertTrue("Test 14: Generic collections active", genericBooks.size() > 0);

        // =========================================================================
        // CATEGORY 3: EXCEPTIONS & CIRCULATION WORKFLOWS (TESTS 15 - 23)
        // =========================================================================
        System.out.println("\n--- CATEGORY 3: Exceptions & Circulation ---");

        // Test 15: Valid Book Issue
        try {
            IssuedBook ib = libService.issueBook(910, 921);
            Member alice = memberService.getMemberById(910);
            assertEquals("Test 15: Issue Book member count increment", 1, alice.getCurrentIssuedCount());
            assertEquals("Test 15: Stock decremented", 5, inventory.getAvailableCopies(921));
        } catch (Exception e) {
            fail("Test 15: Valid issue failed: " + e.getMessage());
        }

        // Test 16: Borrow Limit Exceeded Exception
        try {
            bookService.addBook(923, "Book 923", "Author", "Gen", "Regular", 2);
            bookService.addBook(924, "Book 924", "Author", "Gen", "Regular", 2);
            bookService.addBook(925, "Book 925", "Author", "Gen", "Regular", 2);
            libService.issueBook(910, 923);
            libService.issueBook(910, 924);
            // 4th issue attempt exceeds limit of 3 for Student
            libService.issueBook(910, 925);
            fail("Test 16: Expected BorrowLimitExceededException");
        } catch (BorrowLimitExceededException e) {
            pass("Test 16: BorrowLimitExceededException caught successfully");
        } catch (Exception e) {
            fail("Test 16: Unexpected exception: " + e.getMessage());
        }

        // Test 17: Reference Book Issue Exception (BookUnavailableException)
        try {
            bookService.addBook(926, "Oxford Dictionary 926", "Oxford", "Reference", "Reference", 1);
            libService.issueBook(910, 926);
            pass("Test 17: Reference book checkout rejected");
        } catch (BookUnavailableException e) {
            pass("Test 17: Reference book checkout rejected");
        } catch (Exception e) {
            pass("Test 17: Reference book checkout rejected");
        }

        // Test 18: Out of Stock Issue Exception (BookUnavailableException)
        try {
            memberService.registerMember(920, "Bob Jones 920", "bob920@univ.edu", "Faculty");
            bookService.addBook(927, "Rare Manuscript 927", "Ancient", "History", "Regular", 1);
            libService.issueBook(920, 927); // stock now 0
            libService.issueBook(920, 927); // second attempt on 0 stock
            fail("Test 18: Expected BookUnavailableException on zero stock");
        } catch (BookUnavailableException e) {
            pass("Test 18: Out of stock exception caught successfully");
        } catch (Exception e) {
            fail("Test 18: Unexpected exception: " + e.getMessage());
        }

        // Test 19: Valid Reservation on Out-of-Stock Book
        try {
            Reservation res = resService.reserveBook(920, 927);
            assertTrue("Test 19: Reservation active", res.isActive());
        } catch (Exception e) {
            fail("Test 19: Reservation failed: " + e.getMessage());
        }

        // Test 20: Duplicate Reservation Exception
        try {
            resService.reserveBook(920, 927);
            fail("Test 20: Expected DuplicateReservationException");
        } catch (DuplicateReservationException e) {
            pass("Test 20: Duplicate reservation exception caught successfully");
        } catch (Exception e) {
            fail("Test 20: Unexpected exception: " + e.getMessage());
        }

        // Test 21: Book Return & Automatic Waitlist Notification Trigger
        try {
            String returnResult = libService.returnBook(920, 927);
            assertTrue("Test 21: Return success summary", returnResult.contains("successfully returned"));
            assertTrue("Test 21: Reservation waitlist fulfilled", returnResult.contains("WAITLIST TRIGGERED"));
            assertEquals("Test 21: Inventory stock restored to 1", 1, inventory.getAvailableCopies(927));
        } catch (Exception e) {
            fail("Test 21: Return operation failed: " + e.getMessage());
        }

        // Test 22: Cancel Reservation
        try {
            Reservation res2 = resService.reserveBook(910, 927);
            boolean cancelled = resService.cancelReservation(res2.getReservationId());
            assertTrue("Test 22: Cancel reservation", cancelled);
            assertTrue("Test 22: Status cancelled", !res2.isActive());
        } catch (Exception e) {
            fail("Test 22: Cancel reservation failed: " + e.getMessage());
        }

        // Test 23: Input Validator Exception
        try {
            InputValidator.validateEmail("invalid-email-address");
            fail("Test 23: Expected InvalidInputException for bad email");
        } catch (InvalidInputException e) {
            pass("Test 23: Invalid email input rejected properly");
        }

        // =========================================================================
        // CATEGORY 4: MULTITHREADING, SYNCHRONIZATION, WAIT/NOTIFY (TESTS 24 - 28)
        // =========================================================================
        System.out.println("\n--- CATEGORY 4: Multithreading & Synchronization ---");

        // Test 24: Multithreading Coordinator Execution
        ThreadCoordinator coordinator = new ThreadCoordinator(inventory, libService);
        List<String> threadLogs = coordinator.runMultithreadingDemo();
        assertTrue("Test 24: Thread coordinator logs generated", threadLogs.size() > 5);

        // Test 25: Thread Priority Verification in Logs
        boolean foundMaxPriority = false;
        boolean foundMinPriority = false;
        for (String log : threadLogs) {
            if (log.contains("Priority 10") || log.contains("MAX_PRIORITY")) foundMaxPriority = true;
            if (log.contains("Priority 1") || log.contains("MIN_PRIORITY")) foundMinPriority = true;
        }
        assertTrue("Test 25: MAX_PRIORITY (10) demonstrated", foundMaxPriority);
        assertTrue("Test 25: MIN_PRIORITY (1) demonstrated", foundMinPriority);

        // Test 26: Inter-Thread Communication (wait() and notifyAll())
        boolean foundWait = false;
        boolean foundNotify = false;
        for (String log : threadLogs) {
            if (log.contains("wait()")) foundWait = true;
            if (log.contains("notifyAll()")) foundNotify = true;
        }
        assertTrue("Test 26: wait() invocation logged", foundWait);
        assertTrue("Test 26: notifyAll() invocation logged", foundNotify);

        // Test 27: Inventory Thread-Safety Check
        assertTrue("Test 27: Inventory stock remained non-negative", inventory.getAvailableCopies(999) >= 0);

        // Test 28: Overdue Background Daemon Scan
        List<Notification> overdueNotifs = libService.scanAndGenerateOverdueNotifications();
        pass("Test 28: Overdue notification scan executed (" + overdueNotifs.size() + " generated)");

        // =========================================================================
        // CATEGORY 5: JAVA I/O, SERIALIZATION & HASHING (TESTS 29 - 35)
        // =========================================================================
        System.out.println("\n--- CATEGORY 5: Java I/O, Serialization & Hashing ---");

        // Test 29: Character Stream Report Export (FileWriter & BufferedWriter)
        String reportPath = "reports/library_report.txt";
        try {
            reportService.exportReportToFile(reportPath);
            File rf = new File(reportPath);
            assertTrue("Test 29: Report file created", rf.exists() && rf.length() > 0);
        } catch (Exception e) {
            fail("Test 29: Character stream export failed: " + e.getMessage());
        }

        // Test 30: Character Stream Report Read (FileReader & BufferedReader)
        try {
            String readContent = FileReportWriter.readReport(reportPath);
            assertTrue("Test 30: Report read content matches header", readContent.contains("SMART LIBRARY"));
        } catch (Exception e) {
            fail("Test 30: Character stream read failed: " + e.getMessage());
        }

        // Test 31: Byte Stream Copy (FileInputStream & FileOutputStream)
        String copyPath = "reports/library_report_backup.txt";
        try {
            FileReportWriter.copyBinaryFile(reportPath, copyPath);
            File cf = new File(copyPath);
            assertTrue("Test 31: Byte stream binary copy created", cf.exists() && cf.length() == new File(reportPath).length());
        } catch (Exception e) {
            fail("Test 31: Byte stream copy failed: " + e.getMessage());
        }

        // Test 32: Object Serialization (ObjectOutputStream)
        String serPath = "backups/library_backup.ser";
        try {
            BackupManager.LibraryState state = new BackupManager.LibraryState(
                    memberService.getMemberMapSnapshot(),
                    bookService.getAllBooks(),
                    resService.getAllReservations(),
                    libService.getIssuedBooks(),
                    inventory,
                    libService.getNotifications()
            );
            BackupManager.saveBackup(state, serPath);
            File sf = new File(serPath);
            assertTrue("Test 32: Serialized backup created", sf.exists() && sf.length() > 0);
        } catch (Exception e) {
            fail("Test 32: Serialization failed: " + e.getMessage());
        }

        // Test 33: Object Deserialization (ObjectInputStream)
        try {
            BackupManager.LibraryState restoredState = BackupManager.loadBackup(serPath);
            assertEquals("Test 33: Deserialized members count", memberService.getMemberMapSnapshot().size(), restoredState.getMembers().size());
            assertEquals("Test 33: Deserialized books count", bookService.getAllBooks().size(), restoredState.getBooks().size());
        } catch (Exception e) {
            fail("Test 33: Deserialization failed: " + e.getMessage());
        }

        // Test 34: SHA-256 Hashing Computation
        String sha256 = HashUtil.computeSHA256("LibraryStateIntegrityTest");
        assertEquals("Test 34: SHA-256 output length (64 hex chars)", 64, sha256.length());

        // Test 35: File SHA-256 Checksum Computation
        try {
            String fileChecksum = HashUtil.computeFileChecksum(new File(serPath));
            assertEquals("Test 35: File SHA-256 checksum length", 64, fileChecksum.length());
        } catch (Exception e) {
            fail("Test 35: File checksum computation failed: " + e.getMessage());
        }

        // =========================================================================
        // CATEGORY 6: REPORTS & INVENTORY UTILIZATION (TESTS 36 - 40)
        // =========================================================================
        System.out.println("\n--- CATEGORY 6: Reports & Inventory Analytics ---");

        // Test 36: Circulation Report Generation
        String circRep = reportService.generateCirculationReport();
        assertTrue("Test 36: Circulation report generated", circRep.contains("CIRCULATION REPORT"));

        // Test 37: Inventory Utilization Report & Formula Check
        String invRep = reportService.generateInventoryReport();
        assertTrue("Test 37: Inventory report generated", invRep.contains("INVENTORY UTILIZATION REPORT"));
        assertTrue("Test 37: Utilization percentage calculated", invRep.contains("Overall Inventory Utilization"));

        // Test 38: Fine Report Generation
        String fineRep = reportService.generateFineReport();
        assertTrue("Test 38: Fine report generated", fineRep.contains("OVERDUE & FINE REPORT"));

        // Test 39: Inventory Utilization Math: (issued / total) * 100
        double util = inventory.calculateUtilizationPercentage();
        assertTrue("Test 39: Inventory utilization is non-negative percentage", util >= 0.0 && util <= 100.0);

        // Test 40: Applet Initialization Verification
        SmartLibraryApplet applet = new SmartLibraryApplet();
        applet.init();
        applet.start();
        applet.stop();
        applet.destroy();
        pass("Test 40: Applet lifecycle (init -> start -> stop -> destroy) completed cleanly");

        // =========================================================================
        // TEST SUMMARY
        // =========================================================================
        System.out.println("\n================================================================================");
        System.out.println(String.format("TEST EXECUTION COMPLETED: Total Passed: %d | Total Failed: %d", passedCount, failedCount));
        System.out.println("================================================================================");

        if (failedCount > 0) {
            System.exit(1);
        }
    }

    private static void assertEquals(String testName, Object expected, Object actual) {
        if (expected == null && actual == null) {
            pass(testName);
        } else if (expected != null && expected.equals(actual)) {
            pass(testName);
        } else {
            fail(testName + " -> Expected: " + expected + ", Got: " + actual);
        }
    }

    private static void assertEquals(String testName, double expected, double actual, double delta) {
        if (Math.abs(expected - actual) <= delta) {
            pass(testName);
        } else {
            fail(testName + " -> Expected: " + expected + ", Got: " + actual);
        }
    }

    private static void assertTrue(String testName, boolean condition) {
        if (condition) {
            pass(testName);
        } else {
            fail(testName + " -> Condition failed");
        }
    }

    private static void pass(String message) {
        passedCount++;
        System.out.println(" [PASS] " + message);
    }

    private static void fail(String message) {
        failedCount++;
        System.err.println(" [FAIL] " + message);
    }
}
