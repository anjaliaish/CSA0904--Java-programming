package database;

import model.Book;
import model.FacultyMember;
import model.IssuedBook;
import model.Member;
import model.Notification;
import model.PremiumMember;
import model.RegularBook;
import model.ReferenceBook;
import model.EBook;
import model.Reservation;
import model.StudentMember;
import notification.DueNotification;
import notification.OverdueNotification;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Manages JDBC connectivity, PreparedStatement execution, CRUD operations,
 * and ACID transaction management (commit/rollback) for MySQL persistence.
 */
public class DatabaseManager {

    private static final String DEFAULT_URL = "jdbc:mysql://localhost:3306/library_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASSWORD = "2601";

    private String dbUrl;
    private String dbUser;
    private String dbPassword;
    private Boolean isLiveDatabaseAvailable = null;

    public DatabaseManager() {
        this(DEFAULT_URL, DEFAULT_USER, DEFAULT_PASSWORD);
    }

    public DatabaseManager(String url, String user, String password) {
        this.dbUrl = url;
        this.dbUser = user;
        this.dbPassword = password;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            try {
                // Fallback for older MySQL driver naming
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ignored) {
            }
        }
    }

    public void setCredentials(String url, String user, String password) {
        this.dbUrl = url;
        this.dbUser = user;
        this.dbPassword = password;
        this.isLiveDatabaseAvailable = null; // reset check
    }

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dbUrl, dbUser, dbPassword);
    }

    public synchronized boolean isConnected() {
        if (isLiveDatabaseAvailable == null) {
            try (Connection conn = getConnection()) {
                isLiveDatabaseAvailable = (conn != null && !conn.isClosed());
            } catch (Throwable e) {
                isLiveDatabaseAvailable = false;
            }
        }
        return isLiveDatabaseAvailable;
    }

    public boolean testConnection() {
        isLiveDatabaseAvailable = null;
        return isConnected();
    }

    // =========================================================================
    // MEMBER CRUD (INSERT, SELECT, UPDATE, DELETE)
    // =========================================================================

    public boolean insertMember(Member member) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "INSERT INTO members (member_id, name, email, member_type, borrow_limit, current_issued) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, member.getMemberId());
            ps.setString(2, member.getName());
            ps.setString(3, member.getEmail());
            ps.setString(4, member.getMemberType());
            ps.setInt(5, member.getBorrowLimit());
            ps.setInt(6, member.getCurrentIssuedCount());
            return ps.executeUpdate() > 0;
        }
    }

    public Member getMemberById(int memberId) throws SQLException {
        if (!isConnected())
            return null;
        String sql = "SELECT * FROM members WHERE member_id = ?";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToMember(rs);
                }
            }
        }
        return null;
    }

    public Map<Integer, Member> getAllMembers() throws SQLException {
        Map<Integer, Member> membersMap = new HashMap<Integer, Member>();
        if (!isConnected())
            return membersMap;
        String sql = "SELECT * FROM members ORDER BY member_id ASC";
        try (Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Member m = mapResultSetToMember(rs);
                membersMap.put(m.getMemberId(), m);
            }
        }
        return membersMap;
    }

    public boolean updateMember(Member member) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "UPDATE members SET name = ?, email = ?, member_type = ?, borrow_limit = ?, current_issued = ? WHERE member_id = ?";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, member.getName());
            ps.setString(2, member.getEmail());
            ps.setString(3, member.getMemberType());
            ps.setInt(4, member.getBorrowLimit());
            ps.setInt(5, member.getCurrentIssuedCount());
            ps.setInt(6, member.getMemberId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteMember(int memberId) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "DELETE FROM members WHERE member_id = ?";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, memberId);
            return ps.executeUpdate() > 0;
        }
    }

    private Member mapResultSetToMember(ResultSet rs) throws SQLException {
        int id = rs.getInt("member_id");
        String name = rs.getString("name");
        String email = rs.getString("email");
        String type = rs.getString("member_type");
        int issued = rs.getInt("current_issued");

        if ("Faculty".equalsIgnoreCase(type)) {
            return new FacultyMember(id, name, email, issued);
        } else if ("Premium".equalsIgnoreCase(type)) {
            return new PremiumMember(id, name, email, issued);
        } else {
            return new StudentMember(id, name, email, issued);
        }
    }

    // =========================================================================
    // BOOK CRUD (INSERT, SELECT, UPDATE, DELETE)
    // =========================================================================

    public boolean insertBook(Book book) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "INSERT INTO books (book_id, title, author, category, book_type, total_copies, available_copies) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, book.getBookId());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getAuthor());
            ps.setString(4, book.getCategory());
            ps.setString(5, book.getBookType());
            ps.setInt(6, book.getTotalCopies());
            ps.setInt(7, book.getAvailableCopies());
            return ps.executeUpdate() > 0;
        }
    }

    public Book getBookById(int bookId) throws SQLException {
        if (!isConnected())
            return null;
        String sql = "SELECT * FROM books WHERE book_id = ?";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapResultSetToBook(rs);
                }
            }
        }
        return null;
    }

    public List<Book> getAllBooks() throws SQLException {
        List<Book> books = new ArrayList<Book>();
        if (!isConnected())
            return books;
        String sql = "SELECT * FROM books ORDER BY book_id ASC";
        try (Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                books.add(mapResultSetToBook(rs));
            }
        }
        return books;
    }

    public boolean updateBook(Book book) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "UPDATE books SET title = ?, author = ?, category = ?, book_type = ?, total_copies = ?, available_copies = ? WHERE book_id = ?";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getCategory());
            ps.setString(4, book.getBookType());
            ps.setInt(5, book.getTotalCopies());
            ps.setInt(6, book.getAvailableCopies());
            ps.setInt(7, book.getBookId());
            return ps.executeUpdate() > 0;
        }
    }

    public boolean deleteBook(int bookId) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "DELETE FROM books WHERE book_id = ?";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, bookId);
            return ps.executeUpdate() > 0;
        }
    }

    private Book mapResultSetToBook(ResultSet rs) throws SQLException {
        int id = rs.getInt("book_id");
        String title = rs.getString("title");
        String author = rs.getString("author");
        String cat = rs.getString("category");
        String type = rs.getString("book_type");
        int total = rs.getInt("total_copies");
        int avail = rs.getInt("available_copies");

        if ("Reference".equalsIgnoreCase(type)) {
            return new ReferenceBook(id, title, author, cat, total, avail);
        } else if ("E-Book".equalsIgnoreCase(type) || "EBook".equalsIgnoreCase(type)) {
            return new EBook(id, title, author, cat, total, avail);
        } else {
            return new RegularBook(id, title, author, cat, total, avail);
        }
    }

    // =========================================================================
    // RESERVATIONS CRUD
    // =========================================================================

    public boolean insertReservation(Reservation res) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "INSERT INTO reservations (member_id, book_id, reservation_date, status) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, res.getMemberId());
            ps.setInt(2, res.getBookId());
            ps.setTimestamp(3, new Timestamp(res.getReservationDate().getTime()));
            ps.setString(4, res.getStatus());
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        res.setReservationId(rs.getInt(1));
                    }
                }
                return true;
            }
        }
        return false;
    }

    public List<Reservation> getAllReservations() throws SQLException {
        List<Reservation> list = new ArrayList<Reservation>();
        if (!isConnected())
            return list;
        String sql = "SELECT * FROM reservations ORDER BY reservation_id ASC";
        try (Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Reservation(
                        rs.getInt("reservation_id"),
                        rs.getInt("member_id"),
                        rs.getInt("book_id"),
                        rs.getTimestamp("reservation_date"),
                        rs.getString("status")));
            }
        }
        return list;
    }

    public boolean updateReservationStatus(int reservationId, String status) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "UPDATE reservations SET status = ? WHERE reservation_id = ?";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, status);
            ps.setInt(2, reservationId);
            return ps.executeUpdate() > 0;
        }
    }

    // =========================================================================
    // CIRCULATION & JDBC TRANSACTIONS (ISSUE & RETURN)
    // =========================================================================

    public boolean issueBookTransaction(int memberId, int bookId, java.util.Date issueDate, java.util.Date dueDate)
            throws SQLException {
        if (!isConnected())
            return true; // Allows offline execution mode
        Connection conn = null;
        try {
            conn = getConnection();
            conn.setAutoCommit(false); // Begin ACID Transaction

            // 1. Verify stock availability with row lock
            String checkStockSql = "SELECT available_copies FROM books WHERE book_id = ? FOR UPDATE";
            try (PreparedStatement psCheck = conn.prepareStatement(checkStockSql)) {
                psCheck.setInt(1, bookId);
                try (ResultSet rs = psCheck.executeQuery()) {
                    if (!rs.next() || rs.getInt("available_copies") <= 0) {
                        conn.rollback();
                        return false;
                    }
                }
            }

            // 2. Decrement available copies
            String decStockSql = "UPDATE books SET available_copies = available_copies - 1 WHERE book_id = ?";
            try (PreparedStatement psDec = conn.prepareStatement(decStockSql)) {
                psDec.setInt(1, bookId);
                psDec.executeUpdate();
            }

            // 3. Increment member's current issued count
            String incMemberSql = "UPDATE members SET current_issued = current_issued + 1 WHERE member_id = ?";
            try (PreparedStatement psInc = conn.prepareStatement(incMemberSql)) {
                psInc.setInt(1, memberId);
                psInc.executeUpdate();
            }

            // 4. Insert issued_books record
            String insertIssueSql = "INSERT INTO issued_books (member_id, book_id, issue_date, due_date, return_date, fine) VALUES (?, ?, ?, ?, NULL, 0.00)";
            try (PreparedStatement psIssue = conn.prepareStatement(insertIssueSql)) {
                psIssue.setInt(1, memberId);
                psIssue.setInt(2, bookId);
                psIssue.setDate(3, new Date(issueDate.getTime()));
                psIssue.setDate(4, new Date(dueDate.getTime()));
                psIssue.executeUpdate();
            }

            conn.commit(); // Transaction Complete
            return true;
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ignored) {
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    public boolean returnBookTransaction(int issueId, int memberId, int bookId, double fine) throws SQLException {
        if (!isConnected())
            return true; // Allows offline execution mode
        Connection conn = null;
        try {
            conn = getConnection();
            conn.setAutoCommit(false); // Begin ACID Transaction

            // 1. Update issued_books record with return date and fine
            String updateIssueSql = "UPDATE issued_books SET return_date = ?, fine = ? WHERE issue_id = ? AND return_date IS NULL";
            try (PreparedStatement psUpdate = conn.prepareStatement(updateIssueSql)) {
                psUpdate.setDate(1, new Date(System.currentTimeMillis()));
                psUpdate.setDouble(2, fine);
                psUpdate.setInt(3, issueId);
                int count = psUpdate.executeUpdate();
                if (count == 0) {
                    conn.rollback();
                    return false;
                }
            }

            // 2. Increment available copies in books
            String incStockSql = "UPDATE books SET available_copies = available_copies + 1 WHERE book_id = ?";
            try (PreparedStatement psInc = conn.prepareStatement(incStockSql)) {
                psInc.setInt(1, bookId);
                psInc.executeUpdate();
            }

            // 3. Decrement member's current issued count
            String decMemberSql = "UPDATE members SET current_issued = GREATEST(0, current_issued - 1) WHERE member_id = ?";
            try (PreparedStatement psDec = conn.prepareStatement(decMemberSql)) {
                psDec.setInt(1, memberId);
                psDec.executeUpdate();
            }

            conn.commit(); // Transaction Committed
            return true;
        } catch (SQLException e) {
            if (conn != null) {
                try {
                    conn.rollback();
                } catch (SQLException ignored) {
                }
            }
            throw e;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ignored) {
                }
            }
        }
    }

    public List<IssuedBook> getAllIssuedBooks() throws SQLException {
        List<IssuedBook> list = new ArrayList<IssuedBook>();
        if (!isConnected())
            return list;
        String sql = "SELECT * FROM issued_books ORDER BY issue_id ASC";
        try (Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new IssuedBook(
                        rs.getInt("issue_id"),
                        rs.getInt("member_id"),
                        rs.getInt("book_id"),
                        rs.getDate("issue_date"),
                        rs.getDate("due_date"),
                        rs.getDate("return_date"),
                        rs.getDouble("fine")));
            }
        }
        return list;
    }

    // =========================================================================
    // NOTIFICATIONS CRUD
    // =========================================================================

    public boolean insertNotification(Notification notif) throws SQLException {
        if (!isConnected())
            return false;
        String sql = "INSERT INTO notifications (member_id, message, notification_type, created_at) VALUES (?, ?, ?, ?)";
        try (Connection conn = getConnection();
                PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, notif.getMemberId());
            ps.setString(2, notif.getMessage());
            ps.setString(3, notif.getNotificationType());
            ps.setTimestamp(4, new Timestamp(notif.getCreatedAt().getTime()));
            int affected = ps.executeUpdate();
            if (affected > 0) {
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) {
                        notif.setNotificationId(rs.getInt(1));
                    }
                }
                return true;
            }
        }
        return false;
    }

    public List<Notification> getAllNotifications() throws SQLException {
        List<Notification> list = new ArrayList<Notification>();
        if (!isConnected())
            return list;
        String sql = "SELECT * FROM notifications ORDER BY notification_id ASC";
        try (Connection conn = getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("notification_id");
                int memberId = rs.getInt("member_id");
                String msg = rs.getString("message");
                String type = rs.getString("notification_type");
                Timestamp ts = rs.getTimestamp("created_at");

                if ("DUE_REMINDER".equalsIgnoreCase(type)) {
                    list.add(new DueNotification(id, memberId, msg, ts));
                } else {
                    list.add(new OverdueNotification(id, memberId, msg, ts));
                }
            }
        }
        return list;
    }
}
