package exception;

/**
 * Thrown when a queried book ID or search filter yields no matching catalog records.
 */
public class BookNotFoundException extends Exception {
    public BookNotFoundException(String message) {
        super(message);
    }
}
