package exception;

/**
 * Thrown when an issue request is attempted on a book with zero available copies.
 */
public class BookUnavailableException extends Exception {
    public BookUnavailableException(String message) {
        super(message);
    }
}
