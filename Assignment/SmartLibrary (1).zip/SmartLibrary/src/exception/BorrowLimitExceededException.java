package exception;

/**
 * Thrown when a member has reached or exceeded their maximum concurrent borrow quota.
 */
public class BorrowLimitExceededException extends Exception {
    public BorrowLimitExceededException(String message) {
        super(message);
    }
}
