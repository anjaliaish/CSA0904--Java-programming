package exception;

/**
 * Thrown when a member attempts to reserve a book they have already reserved.
 */
public class DuplicateReservationException extends Exception {
    public DuplicateReservationException(String message) {
        super(message);
    }
}
