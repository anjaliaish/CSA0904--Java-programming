package exception;

/**
 * Thrown when user-provided input fails syntax, format, or semantic constraints.
 */
public class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}
