package exception;

/**
 * Thrown when an operation involves an invalid or unrecognized library member.
 */
public class InvalidMemberException extends Exception {
    public InvalidMemberException(String message) {
        super(message);
    }
}
