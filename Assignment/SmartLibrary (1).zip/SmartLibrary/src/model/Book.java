package model;

import java.io.Serializable;

/**
 * Abstract base class representing a Library Book.
 * Demonstrates encapsulation, private state variables, getters, setters,
 * and polymorphic lending policies across book categories.
 */
public abstract class Book implements Serializable {
    private static final long serialVersionUID = 1L;

    private int bookId;
    private String title;
    private String author;
    private String category;
    private String bookType;
    private int totalCopies;
    private int availableCopies;

    public Book(int bookId, String title, String author, String category, String bookType, int totalCopies, int availableCopies) {
        this.bookId = bookId;
        this.title = title;
        this.author = author;
        this.category = category;
        this.bookType = bookType;
        this.totalCopies = totalCopies;
        this.availableCopies = availableCopies;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getBookType() {
        return bookType;
    }

    public void setBookType(String bookType) {
        this.bookType = bookType;
    }

    public int getTotalCopies() {
        return totalCopies;
    }

    public void setTotalCopies(int totalCopies) {
        this.totalCopies = totalCopies;
    }

    public int getAvailableCopies() {
        return availableCopies;
    }

    public void setAvailableCopies(int availableCopies) {
        this.availableCopies = availableCopies;
    }

    public boolean isAvailable() {
        return availableCopies > 0;
    }

    public void decrementCopies() {
        if (availableCopies > 0) {
            availableCopies--;
        }
    }

    public void incrementCopies() {
        if (availableCopies < totalCopies) {
            availableCopies++;
        }
    }

    /**
     * Polymorphic method to check if this book category is eligible for standard checkout.
     */
    public abstract boolean isLendable();

    /**
     * Polymorphic lending duration period in days.
     */
    public abstract int getDefaultLoanDays();

    @Override
    public String toString() {
        return String.format("ID: %d | %-24s | Author: %-18s | Cat: %-12s | Type: %-10s | Stock: %d/%d",
                bookId, title, author, category, bookType, availableCopies, totalCopies);
    }
}
