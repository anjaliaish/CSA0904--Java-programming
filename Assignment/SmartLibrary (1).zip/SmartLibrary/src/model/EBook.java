package model;

/**
 * Concrete subclass representing a Digital E-Book.
 * E-Books have a 21-day digital checkout period.
 */
public class EBook extends Book {
    private static final long serialVersionUID = 1L;

    public EBook(int bookId, String title, String author, String category, int totalCopies, int availableCopies) {
        super(bookId, title, author, category, "E-Book", totalCopies, availableCopies);
    }

    @Override
    public boolean isLendable() {
        return true;
    }

    @Override
    public int getDefaultLoanDays() {
        return 21;
    }
}
