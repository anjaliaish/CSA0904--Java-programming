package model;

/**
 * Concrete subclass representing a Faculty Member.
 * Demonstrates inheritance and method overriding for borrow limit (10) and fine rate (₹1.00/day).
 */
public class FacultyMember extends Member {
    private static final long serialVersionUID = 1L;
    private static final int BORROW_LIMIT = 10;
    private static final double FINE_PER_DAY = 1.00;

    public FacultyMember(int memberId, String name, String email) {
        super(memberId, name, email, "Faculty");
    }

    public FacultyMember(int memberId, String name, String email, int currentIssuedCount) {
        super(memberId, name, email, "Faculty", currentIssuedCount);
    }

    @Override
    public int getBorrowLimit() {
        return BORROW_LIMIT;
    }

    @Override
    public double calculateFine(int overdueDays) {
        if (overdueDays <= 0) return 0.0;
        return overdueDays * FINE_PER_DAY;
    }
}
