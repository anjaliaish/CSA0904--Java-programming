package model;

import java.io.Serializable;
import java.util.Hashtable;
import java.util.Map;

/**
 * Thread-safe shared resource representing the Library Inventory.
 * Uses Hashtable<Integer, Integer> to map bookId -> availableCopies and bookId -> totalCopies.
 * Implements synchronized methods and inter-thread communication (wait() / notifyAll())
 * to prevent race conditions and stock inconsistencies.
 */
public class Inventory implements Serializable {
    private static final long serialVersionUID = 1L;

    // bookId -> availableCopies
    private final Hashtable<Integer, Integer> availableStock;
    // bookId -> totalCopies
    private final Hashtable<Integer, Integer> totalStock;

    public Inventory() {
        this.availableStock = new Hashtable<Integer, Integer>();
        this.totalStock = new Hashtable<Integer, Integer>();
    }

    /**
     * Initializes or updates stock mappings for a book.
     */
    public synchronized void registerBookStock(int bookId, int total, int available) {
        totalStock.put(bookId, total);
        availableStock.put(bookId, available);
    }

    /**
     * Retrieves the available copies for a book.
     */
    public synchronized int getAvailableCopies(int bookId) {
        Integer copies = availableStock.get(bookId);
        return (copies != null) ? copies : 0;
    }

    /**
     * Retrieves the total copies for a book.
     */
    public synchronized int getTotalCopies(int bookId) {
        Integer total = totalStock.get(bookId);
        return (total != null) ? total : 0;
    }

    /**
     * Synchronized issue operation. Returns true if successfully decremented, false if out of stock.
     */
    public synchronized boolean issueBook(int bookId) {
        int current = getAvailableCopies(bookId);
        if (current > 0) {
            availableStock.put(bookId, current - 1);
            return true;
        }
        return false;
    }

    /**
     * Synchronized return operation. Increments stock without exceeding total copies.
     */
    public synchronized boolean returnBook(int bookId) {
        int current = getAvailableCopies(bookId);
        int total = getTotalCopies(bookId);
        if (current < total) {
            availableStock.put(bookId, current + 1);
            notifyAll(); // Wake up any waiting issue threads
            return true;
        }
        return false;
    }

    /**
     * Demonstrates Inter-Thread Communication:
     * If available stock is 0, the calling thread enters wait() state.
     * When another thread returns a copy, notifyAll() is triggered, waking this thread.
     */
    public synchronized boolean waitAndIssueBook(int bookId, String threadName, java.util.List<String> logList) throws InterruptedException {
        while (getAvailableCopies(bookId) <= 0) {
            String msg = "[" + threadName + "] Stock is 0 for Book #" + bookId + ". Entering wait()...";
            if (logList != null) logList.add(msg);
            System.out.println(msg);
            wait(); // Releases monitor and waits
            String resumeMsg = "[" + threadName + "] Woken up by notifyAll()! Re-checking inventory for Book #" + bookId;
            if (logList != null) logList.add(resumeMsg);
            System.out.println(resumeMsg);
        }

        // Successfully woke up and verified stock > 0
        int current = availableStock.get(bookId);
        availableStock.put(bookId, current - 1);
        String successMsg = "[" + threadName + "] Successfully issued Book #" + bookId + ". Remaining stock: " + (current - 1);
        if (logList != null) logList.add(successMsg);
        System.out.println(successMsg);
        return true;
    }

    /**
     * Returns a book with explicit inter-thread notification logging.
     */
    public synchronized void returnBookAndNotify(int bookId, String threadName, java.util.List<String> logList) {
        int current = getAvailableCopies(bookId);
        int total = getTotalCopies(bookId);
        if (current < total) {
            availableStock.put(bookId, current + 1);
        }
        String msg = "[" + threadName + "] Book #" + bookId + " returned! New stock: " + (current + 1) + ". Calling notifyAll()...";
        if (logList != null) logList.add(msg);
        System.out.println(msg);
        notifyAll(); // Signal all waiting threads
    }

    /**
     * Calculates overall library inventory utilization percentage:
     * (issued copies / total copies) * 100
     */
    public synchronized double calculateUtilizationPercentage() {
        int sumTotal = 0;
        int sumAvailable = 0;
        for (Map.Entry<Integer, Integer> entry : totalStock.entrySet()) {
            sumTotal += entry.getValue();
            Integer avail = availableStock.get(entry.getKey());
            sumAvailable += (avail != null) ? avail : 0;
        }
        if (sumTotal == 0) return 0.0;
        int issued = sumTotal - sumAvailable;
        return ((double) issued / sumTotal) * 100.0;
    }

    public synchronized int getTotalLibraryCopies() {
        int sum = 0;
        for (int count : totalStock.values()) {
            sum += count;
        }
        return sum;
    }

    public synchronized int getTotalAvailableCopies() {
        int sum = 0;
        for (int count : availableStock.values()) {
            sum += count;
        }
        return sum;
    }

    public synchronized int getTotalIssuedCopies() {
        return getTotalLibraryCopies() - getTotalAvailableCopies();
    }

    public Hashtable<Integer, Integer> getAvailableStockSnapshot() {
        return new Hashtable<Integer, Integer>(availableStock);
    }

    public Hashtable<Integer, Integer> getTotalStockSnapshot() {
        return new Hashtable<Integer, Integer>(totalStock);
    }
}
