package model;

import java.io.Serializable;

/**
 * Abstract base class representing a Library Member.
 * Demonstrates encapsulation, data hiding, constructors, getters/setters,
 * and declares polymorphic contracts for fine computation and borrow limits.
 */
public abstract class Member implements Serializable {
    private static final long serialVersionUID = 1L;

    private int memberId;
    private String name;
    private String email;
    private String memberType;
    private int currentIssuedCount;

    public Member(int memberId, String name, String email, String memberType) {
        this.memberId = memberId;
        this.name = name;
        this.email = email;
        this.memberType = memberType;
        this.currentIssuedCount = 0;
    }

    public Member(int memberId, String name, String email, String memberType, int currentIssuedCount) {
        this.memberId = memberId;
        this.name = name;
        this.email = email;
        this.memberType = memberType;
        this.currentIssuedCount = currentIssuedCount;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMemberType() {
        return memberType;
    }

    public void setMemberType(String memberType) {
        this.memberType = memberType;
    }

    public int getCurrentIssuedCount() {
        return currentIssuedCount;
    }

    public void setCurrentIssuedCount(int currentIssuedCount) {
        this.currentIssuedCount = currentIssuedCount;
    }

    public boolean canBorrow() {
        return currentIssuedCount < getBorrowLimit();
    }

    public void incrementIssuedCount() {
        this.currentIssuedCount++;
    }

    public void decrementIssuedCount() {
        if (this.currentIssuedCount > 0) {
            this.currentIssuedCount--;
        }
    }

    /**
     * Polymorphic method to calculate fine based on overdue days.
     * Overridden by concrete member subclasses.
     */
    public abstract double calculateFine(int overdueDays);

    /**
     * Polymorphic method returning member-specific concurrent borrowing quota.
     */
    public abstract int getBorrowLimit();

    @Override
    public String toString() {
        return String.format("ID: %d | Name: %-18s | Email: %-22s | Type: %-8s | Active: %d/%d",
                memberId, name, email, memberType, currentIssuedCount, getBorrowLimit());
    }
}
