package model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Abstract base class representing a Library Notification.
 * Demonstrates inheritance and declares polymorphic notification delivery contracts.
 */
public abstract class Notification implements Serializable {
    private static final long serialVersionUID = 1L;

    private int notificationId;
    private int memberId;
    private String message;
    private String notificationType;
    private Date createdAt;

    public Notification(int notificationId, int memberId, String message, String notificationType) {
        this.notificationId = notificationId;
        this.memberId = memberId;
        this.message = message;
        this.notificationType = notificationType;
        this.createdAt = new Date();
    }

    public Notification(int notificationId, int memberId, String message, String notificationType, Date createdAt) {
        this.notificationId = notificationId;
        this.memberId = memberId;
        this.message = message;
        this.notificationType = notificationType;
        this.createdAt = createdAt;
    }

    public int getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getNotificationType() {
        return notificationType;
    }

    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    /**
     * Polymorphic method to format the notification for display and export.
     */
    public abstract String formatNotification();

    /**
     * Polymorphic send action.
     */
    public String send() {
        return formatNotification();
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String time = (createdAt != null) ? sdf.format(createdAt) : "N/A";
        return String.format("[%s] #%d (Member #%d): %s", time, notificationId, memberId, message);
    }
}
