package model;

/**
 * Concrete subclass representing a Premium Member.
 * Demonstrates inheritance and method overriding for borrow limit (15) and fine rate (₹0.50/day).
 */
public class PremiumMember extends Member {
    private static final long serialVersionUID = 1L;
    private static final int BORROW_LIMIT = 15;
    private static final double FINE_PER_DAY = 0.50;

    public PremiumMember(int memberId, String name, String email) {
        super(memberId, name, email, "Premium");
    }

    public PremiumMember(int memberId, String name, String email, int currentIssuedCount) {
        super(memberId, name, email, "Premium", currentIssuedCount);
    }

    @Override
    public int getBorrowLimit() {
        return BORROW_LIMIT;
    }

    @Override
    public double calculateFine(int overdueDays) {
        if (overdueDays <= 0) return 0.0;
        return overdueDays * FINE_PER_DAY;
    }
}
