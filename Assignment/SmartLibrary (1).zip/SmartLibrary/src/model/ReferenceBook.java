package model;

/**
 * Concrete subclass representing a Reference-Only Book (e.g. encyclopedias, journals).
 * Reference books are for reading room use only and cannot be issued outside the library.
 */
public class ReferenceBook extends Book {
    private static final long serialVersionUID = 1L;

    public ReferenceBook(int bookId, String title, String author, String category, int totalCopies, int availableCopies) {
        super(bookId, title, author, category, "Reference", totalCopies, availableCopies);
    }

    @Override
    public boolean isLendable() {
        return false; // Reference books cannot be checked out
    }

    @Override
    public int getDefaultLoanDays() {
        return 0; // Reading room only
    }
}
