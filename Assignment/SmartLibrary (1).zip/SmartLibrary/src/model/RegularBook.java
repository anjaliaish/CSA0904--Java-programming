package model;

/**
 * Concrete subclass representing a Regular Physical Book.
 * Allows standard checkout with a 14-day borrowing loan duration.
 */
public class RegularBook extends Book {
    private static final long serialVersionUID = 1L;

    public RegularBook(int bookId, String title, String author, String category, int totalCopies, int availableCopies) {
        super(bookId, title, author, category, "Regular", totalCopies, availableCopies);
    }

    @Override
    public boolean isLendable() {
        return true;
    }

    @Override
    public int getDefaultLoanDays() {
        return 14;
    }
}
