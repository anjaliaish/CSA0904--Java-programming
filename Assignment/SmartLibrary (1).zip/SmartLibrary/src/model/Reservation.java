package model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Encapsulates a book reservation in the reservation waitlist.
 * Fields are private with full getter/setter encapsulation.
 */
public class Reservation implements Serializable {
    private static final long serialVersionUID = 1L;

    private int reservationId;
    private int memberId;
    private int bookId;
    private Date reservationDate;
    private String status; // "ACTIVE", "FULFILLED", "CANCELLED"

    public Reservation(int reservationId, int memberId, int bookId, Date reservationDate, String status) {
        this.reservationId = reservationId;
        this.memberId = memberId;
        this.bookId = bookId;
        this.reservationDate = reservationDate;
        this.status = status;
    }

    public int getReservationId() {
        return reservationId;
    }

    public void setReservationId(int reservationId) {
        this.reservationId = reservationId;
    }

    public int getMemberId() {
        return memberId;
    }

    public void setMemberId(int memberId) {
        this.memberId = memberId;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public Date getReservationDate() {
        return reservationDate;
    }

    public void setReservationDate(Date reservationDate) {
        this.reservationDate = reservationDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public boolean isActive() {
        return "ACTIVE".equalsIgnoreCase(this.status);
    }

    @Override
    public String toString() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        String dateStr = (reservationDate != null) ? sdf.format(reservationDate) : "N/A";
        return String.format("Res ID: %d | Member ID: %d | Book ID: %d | Date: %s | Status: %s",
                reservationId, memberId, bookId, dateStr, status);
    }
}
