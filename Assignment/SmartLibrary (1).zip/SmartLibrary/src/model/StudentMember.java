package model;

/**
 * Concrete subclass representing a Student Member.
 * Demonstrates inheritance, superclass constructor invocation,
 * and method overriding for borrow limit (3) and fine rate (₹2.00/day).
 */
public class StudentMember extends Member {
    private static final long serialVersionUID = 1L;
    private static final int BORROW_LIMIT = 3;
    private static final double FINE_PER_DAY = 2.00;

    public StudentMember(int memberId, String name, String email) {
        super(memberId, name, email, "Student");
    }

    public StudentMember(int memberId, String name, String email, int currentIssuedCount) {
        super(memberId, name, email, "Student", currentIssuedCount);
    }

    @Override
    public int getBorrowLimit() {
        return BORROW_LIMIT;
    }

    @Override
    public double calculateFine(int overdueDays) {
        if (overdueDays <= 0) return 0.0;
        return overdueDays * FINE_PER_DAY;
    }
}
