package notification;

import model.Notification;
import java.util.Date;

/**
 * Concrete Notification subclass for upcoming due-date reminders.
 * Demonstrates inheritance and polymorphic message formatting.
 */
public class DueNotification extends Notification {
    private static final long serialVersionUID = 1L;

    private int bookId;
    private String bookTitle;
    private Date dueDate;

    public DueNotification(int notificationId, int memberId, int bookId, String bookTitle, Date dueDate) {
        super(notificationId, memberId, 
              "Friendly Reminder: Book '" + bookTitle + "' (ID: " + bookId + ") is due soon.",
              "DUE_REMINDER");
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.dueDate = dueDate;
    }

    public DueNotification(int notificationId, int memberId, String message, Date createdAt) {
        super(notificationId, memberId, message, "DUE_REMINDER", createdAt);
    }

    public int getBookId() {
        return bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public Date getDueDate() {
        return dueDate;
    }

    @Override
    public String formatNotification() {
        return "[UPCOMING DUE DATE] Member #" + getMemberId() + " -> " + getMessage();
    }
}
