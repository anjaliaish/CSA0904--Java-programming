package notification;

import model.Notification;
import java.util.Date;

/**
 * Concrete Notification subclass for overdue books and accrued fine notices.
 * Demonstrates inheritance and polymorphic message formatting with financial data.
 */
public class OverdueNotification extends Notification {
    private static final long serialVersionUID = 1L;

    private int bookId;
    private String bookTitle;
    private int overdueDays;
    private double fineAmount;

    public OverdueNotification(int notificationId, int memberId, int bookId, String bookTitle, int overdueDays, double fineAmount) {
        super(notificationId, memberId,
              String.format("OVERDUE ALERT: Book '%s' (ID: %d) is overdue by %d days. Accrued Fine: ₹%.2f",
                            bookTitle, bookId, overdueDays, fineAmount),
              "OVERDUE_ALERT");
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.overdueDays = overdueDays;
        this.fineAmount = fineAmount;
    }

    public OverdueNotification(int notificationId, int memberId, String message, Date createdAt) {
        super(notificationId, memberId, message, "OVERDUE_ALERT", createdAt);
    }

    public int getBookId() {
        return bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public int getOverdueDays() {
        return overdueDays;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    @Override
    public String formatNotification() {
        return "[OVERDUE NOTICE] Member #" + getMemberId() + " -> " + getMessage();
    }
}
