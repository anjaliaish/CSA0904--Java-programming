package service;

import database.DatabaseManager;
import exception.BookNotFoundException;
import exception.InvalidInputException;
import model.Book;
import model.Inventory;
import model.RegularBook;
import model.ReferenceBook;
import model.EBook;
import util.InputValidator;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

/**
 * Service managing books in the library.
 * Genuinely uses:
 *  - ArrayList<Book> for catalog storage
 *  - HashSet<String> for unique categories collection
 *  - Iterator<Book> for search and traversal
 *  - ListIterator<Book> for in-place index-aware updates and bidirectional inspection
 */
public class BookService {

    private final ArrayList<Book> bookList;
    private final HashSet<String> categoriesSet;
    private final Inventory inventory;
    private final DatabaseManager dbManager;

    public BookService(Inventory inventory, DatabaseManager dbManager) {
        this.bookList = new ArrayList<Book>();
        this.categoriesSet = new HashSet<String>();
        this.inventory = inventory;
        this.dbManager = dbManager;
        loadBooksFromDatabase();
    }

    public void loadBooksFromDatabase() {
        if (dbManager != null) {
            try {
                List<Book> loaded = dbManager.getAllBooks();
                bookList.clear();
                categoriesSet.clear();
                for (Book b : loaded) {
                    bookList.add(b);
                    categoriesSet.add(b.getCategory());
                    if (inventory != null) {
                        inventory.registerBookStock(b.getBookId(), b.getTotalCopies(), b.getAvailableCopies());
                    }
                }
            } catch (SQLException e) {
                System.err.println("Warning: Could not load books from DB: " + e.getMessage());
            }
        }
    }

    /**
     * Adds a new book to the catalog.
     */
    public synchronized Book addBook(int bookId, String title, String author, String category, String bookType, int totalCopies)
            throws InvalidInputException, SQLException {
        
        InputValidator.validatePositiveInt(String.valueOf(bookId), "Book ID");
        title = InputValidator.validateNonEmptyString(title, "Book Title");
        author = InputValidator.validateNonEmptyString(author, "Author");
        category = InputValidator.validateNonEmptyString(category, "Category");
        totalCopies = InputValidator.validatePositiveInt(String.valueOf(totalCopies), "Total Copies");

        // Verify duplicate Book ID using Iterator
        Iterator<Book> it = bookList.iterator();
        while (it.hasNext()) {
            Book existing = it.next();
            if (existing.getBookId() == bookId) {
                throw new InvalidInputException("Book with ID " + bookId + " already exists in catalog.");
            }
        }

        Book book;
        if ("Reference".equalsIgnoreCase(bookType)) {
            book = new ReferenceBook(bookId, title, author, category, totalCopies, totalCopies);
        } else if ("E-Book".equalsIgnoreCase(bookType) || "EBook".equalsIgnoreCase(bookType)) {
            book = new EBook(bookId, title, author, category, totalCopies, totalCopies);
        } else {
            book = new RegularBook(bookId, title, author, category, totalCopies, totalCopies);
        }

        if (dbManager != null) {
            dbManager.insertBook(book);
        }

        bookList.add(book);
        categoriesSet.add(category);
        if (inventory != null) {
            inventory.registerBookStock(bookId, totalCopies, totalCopies);
        }

        return book;
    }

    public Book getBookById(int bookId) throws BookNotFoundException {
        Iterator<Book> it = bookList.iterator();
        while (it.hasNext()) {
            Book b = it.next();
            if (b.getBookId() == bookId) {
                return b;
            }
        }
        throw new BookNotFoundException("Book with ID " + bookId + " was not found in catalog.");
    }

    /**
     * Searches books by title, author, or category using Iterator.
     */
    public List<Book> searchBooks(String query) {
        List<Book> results = new ArrayList<Book>();
        if (query == null || query.trim().isEmpty()) {
            results.addAll(bookList);
            return results;
        }
        String q = query.trim().toLowerCase();

        Iterator<Book> it = bookList.iterator();
        while (it.hasNext()) {
            Book b = it.next();
            if (String.valueOf(b.getBookId()).contains(q) ||
                b.getTitle().toLowerCase().contains(q) ||
                b.getAuthor().toLowerCase().contains(q) ||
                b.getCategory().toLowerCase().contains(q) ||
                b.getBookType().toLowerCase().contains(q)) {
                results.add(b);
            }
        }
        return results;
    }

    /**
     * Updates an existing book using ListIterator for in-place replacement.
     */
    public synchronized boolean updateBook(int bookId, String title, String author, String category, String bookType, int totalCopies)
            throws InvalidInputException, BookNotFoundException, SQLException {
        
        title = InputValidator.validateNonEmptyString(title, "Book Title");
        author = InputValidator.validateNonEmptyString(author, "Author");
        category = InputValidator.validateNonEmptyString(category, "Category");
        totalCopies = InputValidator.validatePositiveInt(String.valueOf(totalCopies), "Total Copies");

        boolean updated = false;
        ListIterator<Book> listIt = bookList.listIterator();
        while (listIt.hasNext()) {
            Book oldBook = listIt.next();
            if (oldBook.getBookId() == bookId) {
                int issuedCount = oldBook.getTotalCopies() - oldBook.getAvailableCopies();
                if (totalCopies < issuedCount) {
                    throw new InvalidInputException("New total copies (" + totalCopies + ") cannot be less than active issued copies (" + issuedCount + ").");
                }
                int newAvailable = totalCopies - issuedCount;

                Book newBook;
                if ("Reference".equalsIgnoreCase(bookType)) {
                    newBook = new ReferenceBook(bookId, title, author, category, totalCopies, newAvailable);
                } else if ("E-Book".equalsIgnoreCase(bookType) || "EBook".equalsIgnoreCase(bookType)) {
                    newBook = new EBook(bookId, title, author, category, totalCopies, newAvailable);
                } else {
                    newBook = new RegularBook(bookId, title, author, category, totalCopies, newAvailable);
                }

                if (dbManager != null) {
                    dbManager.updateBook(newBook);
                }

                // In-place replacement via ListIterator
                listIt.set(newBook);
                categoriesSet.add(category);
                if (inventory != null) {
                    inventory.registerBookStock(bookId, totalCopies, newAvailable);
                }
                updated = true;
                break;
            }
        }

        if (!updated) {
            throw new BookNotFoundException("Book with ID " + bookId + " not found for update.");
        }
        return true;
    }

    public synchronized boolean deleteBook(int bookId) throws BookNotFoundException, InvalidInputException, SQLException {
        Book b = getBookById(bookId);
        int issuedCount = b.getTotalCopies() - b.getAvailableCopies();
        if (issuedCount > 0) {
            throw new InvalidInputException("Cannot delete Book #" + bookId + " because " + issuedCount + " copies are currently issued.");
        }

        if (dbManager != null) {
            dbManager.deleteBook(bookId);
        }

        Iterator<Book> it = bookList.iterator();
        while (it.hasNext()) {
            if (it.next().getBookId() == bookId) {
                it.remove();
                break;
            }
        }
        refreshCategories();
        return true;
    }

    private void refreshCategories() {
        categoriesSet.clear();
        for (Book b : bookList) {
            categoriesSet.add(b.getCategory());
        }
    }

    public List<Book> getAllBooks() {
        return new ArrayList<Book>(bookList);
    }

    public Set<String> getUniqueCategories() {
        return new HashSet<String>(categoriesSet);
    }
}
