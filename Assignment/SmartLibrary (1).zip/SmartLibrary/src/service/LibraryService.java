package service;

import database.DatabaseManager;
import exception.BookNotFoundException;
import exception.BookUnavailableException;
import exception.BorrowLimitExceededException;
import exception.InvalidInputException;
import exception.InvalidMemberException;
import model.Book;
import model.Inventory;
import model.IssuedBook;
import model.Member;
import model.Notification;
import model.Reservation;
import notification.DueNotification;
import notification.OverdueNotification;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Central circulation and coordination service.
 * Handles issue, return, waitlist triggers, fine calculations,
 * and automated overdue notification scanning.
 */
public class LibraryService {

    private final MemberService memberService;
    private final BookService bookService;
    private final ReservationService reservationService;
    private final Inventory inventory;
    private final DatabaseManager dbManager;

    private final List<IssuedBook> issuedBooksList;
    private final List<Notification> notificationsList;
    private int nextIssueId = 1000;
    private int nextNotifId = 1000;

    public LibraryService(MemberService memberService,
                          BookService bookService,
                          ReservationService reservationService,
                          Inventory inventory,
                          DatabaseManager dbManager) {
        this.memberService = memberService;
        this.bookService = bookService;
        this.reservationService = reservationService;
        this.inventory = inventory;
        this.dbManager = dbManager;
        this.issuedBooksList = new ArrayList<IssuedBook>();
        this.notificationsList = new ArrayList<Notification>();
        loadCirculationFromDatabase();
    }

    public void loadCirculationFromDatabase() {
        if (dbManager != null) {
            try {
                List<IssuedBook> loadedIssues = dbManager.getAllIssuedBooks();
                issuedBooksList.clear();
                issuedBooksList.addAll(loadedIssues);

                List<Notification> loadedNotifs = dbManager.getAllNotifications();
                notificationsList.clear();
                notificationsList.addAll(loadedNotifs);
            } catch (SQLException e) {
                System.err.println("Warning: Could not load circulation data: " + e.getMessage());
            }
        }
    }

    /**
     * Issues a book to a member.
     * Enforces member borrow limits, book lendability, and real-time inventory checks.
     */
    public synchronized IssuedBook issueBook(int memberId, int bookId)
            throws InvalidMemberException, BookNotFoundException, BookUnavailableException, BorrowLimitExceededException, SQLException {
        
        Member member = memberService.getMemberById(memberId);
        Book book = bookService.getBookById(bookId);

        if (!member.canBorrow()) {
            throw new BorrowLimitExceededException(
                "Borrow Limit Exceeded: " + member.getMemberType() + " member #" + memberId +
                " has reached their max limit of " + member.getBorrowLimit() + " book(s)."
            );
        }

        if (!book.isLendable()) {
            throw new BookUnavailableException("Book #" + bookId + " is a Reference Book and cannot be checked out.");
        }

        if (inventory.getAvailableCopies(bookId) <= 0) {
            throw new BookUnavailableException(
                "Book #" + bookId + " ('" + book.getTitle() + "') is currently out of stock. You can place a reservation."
            );
        }

        Date issueDate = new Date();
        Calendar cal = Calendar.getInstance();
        cal.setTime(issueDate);
        cal.add(Calendar.DAY_OF_YEAR, book.getDefaultLoanDays());
        Date dueDate = cal.getTime();

        // Perform JDBC transaction
        if (dbManager != null) {
            boolean success = dbManager.issueBookTransaction(memberId, bookId, issueDate, dueDate);
            if (!success) {
                throw new BookUnavailableException("Database transaction aborted: book is no longer available.");
            }
        }

        // Update in-memory state
        inventory.issueBook(bookId);
        book.decrementCopies();
        member.incrementIssuedCount();

        IssuedBook issueRecord = new IssuedBook(++nextIssueId, memberId, bookId, issueDate, dueDate, null, 0.0);
        issuedBooksList.add(issueRecord);

        // Generate Due Notification
        DueNotification dueNotif = new DueNotification(++nextNotifId, memberId, bookId, book.getTitle(), dueDate);
        if (dbManager != null) {
            try { dbManager.insertNotification(dueNotif); } catch (SQLException ignored) {}
        }
        notificationsList.add(dueNotif);

        return issueRecord;
    }

    /**
     * Processes book return, calculates polymorphic fines, increments inventory,
     * and fulfills reservation waitlists.
     */
    public synchronized String returnBook(int memberId, int bookId)
            throws InvalidMemberException, BookNotFoundException, InvalidInputException, SQLException {
        
        Member member = memberService.getMemberById(memberId);
        Book book = bookService.getBookById(bookId);

        IssuedBook activeRecord = null;
        for (IssuedBook ib : issuedBooksList) {
            if (ib.getMemberId() == memberId && ib.getBookId() == bookId && !ib.isReturned()) {
                activeRecord = ib;
                break;
            }
        }

        if (activeRecord == null) {
            throw new InvalidInputException("No active checkout found for Member #" + memberId + " and Book #" + bookId + ".");
        }

        Date returnDate = new Date();
        long diffMillis = returnDate.getTime() - activeRecord.getDueDate().getTime();
        int overdueDays = 0;
        if (diffMillis > 0) {
            overdueDays = (int) Math.ceil((double) diffMillis / (1000 * 60 * 60 * 24));
        }

        // Polymorphic fine calculation
        double fine = member.calculateFine(overdueDays);

        // Perform JDBC transaction
        if (dbManager != null) {
            dbManager.returnBookTransaction(activeRecord.getIssueId(), memberId, bookId, fine);
        }

        // Update in-memory state
        activeRecord.setReturnDate(returnDate);
        activeRecord.setFine(fine);
        inventory.returnBook(bookId);
        book.incrementCopies();
        member.decrementIssuedCount();

        StringBuilder summary = new StringBuilder();
        summary.append(String.format("Book '%s' (ID: %d) successfully returned by %s (%s).\n",
                book.getTitle(), bookId, member.getName(), member.getMemberType()));
        summary.append(String.format("Overdue Days: %d | Fine Assessed: ₹%.2f\n", overdueDays, fine));

        // Check and fulfill reservation waitlist
        Reservation nextRes = reservationService.fulfillNextReservation(bookId);
        if (nextRes != null) {
            String resMsg = "RESERVATION READY: Book '" + book.getTitle() + "' (ID: " + bookId + ") is now available for reserved Member #" + nextRes.getMemberId() + "!";
            DueNotification resNotif = new DueNotification(++nextNotifId, nextRes.getMemberId(), resMsg, new Date());
            if (dbManager != null) {
                try { dbManager.insertNotification(resNotif); } catch (SQLException ignored) {}
            }
            notificationsList.add(resNotif);
            summary.append("\n>> WAITLIST TRIGGERED: Notified reserved Member #" + nextRes.getMemberId() + " that the book is ready!");
        }

        return summary.toString();
    }

    /**
     * Checks all active checkouts for overdue status and polymorphically creates overdue notifications.
     */
    public synchronized List<Notification> scanAndGenerateOverdueNotifications() {
        List<Notification> newNotifs = new ArrayList<Notification>();
        Date now = new Date();

        for (IssuedBook ib : issuedBooksList) {
            if (!ib.isReturned() && now.after(ib.getDueDate())) {
                try {
                    Member m = memberService.getMemberById(ib.getMemberId());
                    Book b = bookService.getBookById(ib.getBookId());
                    long diff = now.getTime() - ib.getDueDate().getTime();
                    int days = (int) Math.ceil((double) diff / (1000 * 60 * 60 * 24));
                    double fine = m.calculateFine(days);

                    OverdueNotification notif = new OverdueNotification(
                            ++nextNotifId, m.getMemberId(), b.getBookId(), b.getTitle(), days, fine
                    );

                    if (dbManager != null) {
                        try { dbManager.insertNotification(notif); } catch (SQLException ignored) {}
                    }
                    notificationsList.add(notif);
                    newNotifs.add(notif);
                } catch (Exception ignored) {}
            }
        }
        return newNotifs;
    }

    public List<IssuedBook> getIssuedBooks() {
        return new ArrayList<IssuedBook>(issuedBooksList);
    }

    public List<Notification> getNotifications() {
        return new ArrayList<Notification>(notificationsList);
    }

    public Inventory getInventory() {
        return inventory;
    }

    public MemberService getMemberService() {
        return memberService;
    }

    public BookService getBookService() {
        return bookService;
    }

    public ReservationService getReservationService() {
        return reservationService;
    }
}
