package service;

import database.DatabaseManager;
import exception.InvalidInputException;
import exception.InvalidMemberException;
import model.Member;
import model.StudentMember;
import model.FacultyMember;
import model.PremiumMember;
import util.InputValidator;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * Service managing library members.
 * Genuinely utilizes HashMap<Integer, Member> for O(1) primary key lookup
 * and demonstrates Iterator<Member> for traversal, search, and filtering.
 */
public class MemberService {

    // member ID -> Member object
    private final HashMap<Integer, Member> memberMap;
    private final DatabaseManager dbManager;

    public MemberService(DatabaseManager dbManager) {
        this.memberMap = new HashMap<Integer, Member>();
        this.dbManager = dbManager;
        loadMembersFromDatabase();
    }

    public void loadMembersFromDatabase() {
        if (dbManager != null) {
            try {
                Map<Integer, Member> loaded = dbManager.getAllMembers();
                memberMap.clear();
                memberMap.putAll(loaded);
            } catch (SQLException e) {
                System.err.println("Warning: Could not load members from DB: " + e.getMessage());
            }
        }
    }

    /**
     * Registers a new member with validation against duplicate IDs and duplicate emails.
     */
    public synchronized Member registerMember(int memberId, String name, String email, String memberType)
            throws InvalidInputException, InvalidMemberException, SQLException {
        
        InputValidator.validatePositiveInt(String.valueOf(memberId), "Member ID");
        name = InputValidator.validateNonEmptyString(name, "Member Name");
        email = InputValidator.validateEmail(email);

        if (memberMap.containsKey(memberId)) {
            throw new InvalidMemberException("Member with ID " + memberId + " already exists.");
        }

        // Check duplicate email using Iterator
        Iterator<Member> it = memberMap.values().iterator();
        while (it.hasNext()) {
            Member existing = it.next();
            if (existing.getEmail().equalsIgnoreCase(email)) {
                throw new InvalidMemberException("A member with email '" + email + "' is already registered (ID: " + existing.getMemberId() + ").");
            }
        }

        Member member;
        if ("Faculty".equalsIgnoreCase(memberType)) {
            member = new FacultyMember(memberId, name, email);
        } else if ("Premium".equalsIgnoreCase(memberType)) {
            member = new PremiumMember(memberId, name, email);
        } else {
            member = new StudentMember(memberId, name, email);
        }

        // Persist in DB
        if (dbManager != null) {
            dbManager.insertMember(member);
        }

        // Update in-memory HashMap
        memberMap.put(memberId, member);
        return member;
    }

    public Member getMemberById(int memberId) throws InvalidMemberException {
        Member m = memberMap.get(memberId);
        if (m == null) {
            throw new InvalidMemberException("Member with ID " + memberId + " not found.");
        }
        return m;
    }

    /**
     * Searches members matching a query string using Iterator traversal.
     */
    public List<Member> searchMembers(String query) {
        List<Member> results = new ArrayList<Member>();
        if (query == null || query.trim().isEmpty()) {
            results.addAll(memberMap.values());
            return results;
        }
        String q = query.trim().toLowerCase();

        Iterator<Member> it = memberMap.values().iterator();
        while (it.hasNext()) {
            Member m = it.next();
            if (String.valueOf(m.getMemberId()).contains(q) ||
                m.getName().toLowerCase().contains(q) ||
                m.getEmail().toLowerCase().contains(q) ||
                m.getMemberType().toLowerCase().contains(q)) {
                results.add(m);
            }
        }
        return results;
    }

    public synchronized boolean updateMember(int memberId, String name, String email, String memberType)
            throws InvalidInputException, InvalidMemberException, SQLException {
        
        Member existing = getMemberById(memberId);
        name = InputValidator.validateNonEmptyString(name, "Member Name");
        email = InputValidator.validateEmail(email);

        // Verify email uniqueness excluding self
        Iterator<Member> it = memberMap.values().iterator();
        while (it.hasNext()) {
            Member other = it.next();
            if (other.getMemberId() != memberId && other.getEmail().equalsIgnoreCase(email)) {
                throw new InvalidMemberException("Email '" + email + "' is already used by Member #" + other.getMemberId());
            }
        }

        int currentIssued = existing.getCurrentIssuedCount();
        Member updated;
        if ("Faculty".equalsIgnoreCase(memberType)) {
            updated = new FacultyMember(memberId, name, email, currentIssued);
        } else if ("Premium".equalsIgnoreCase(memberType)) {
            updated = new PremiumMember(memberId, name, email, currentIssued);
        } else {
            updated = new StudentMember(memberId, name, email, currentIssued);
        }

        if (dbManager != null) {
            dbManager.updateMember(updated);
        }

        memberMap.put(memberId, updated);
        return true;
    }

    public synchronized boolean deleteMember(int memberId) throws InvalidMemberException, SQLException {
        Member m = getMemberById(memberId);
        if (m.getCurrentIssuedCount() > 0) {
            throw new InvalidMemberException("Cannot delete Member #" + memberId + " with " + m.getCurrentIssuedCount() + " active borrowed book(s).");
        }

        if (dbManager != null) {
            dbManager.deleteMember(memberId);
        }
        memberMap.remove(memberId);
        return true;
    }

    public Map<Integer, Member> getMemberMapSnapshot() {
        return new HashMap<Integer, Member>(memberMap);
    }
}
