package service;

import model.Book;
import model.Inventory;
import model.IssuedBook;
import model.Member;
import model.Reservation;
import util.FileReportWriter;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * Generates Circulation, Inventory Utilization, and Overdue Fine reports.
 * Formats data and exports text reports via Character Streams.
 */
public class ReportService {

    private final LibraryService libraryService;

    public ReportService(LibraryService libraryService) {
        this.libraryService = libraryService;
    }

    public String generateCirculationReport() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sb.append("========================================================================================\n");
        sb.append("                      SMART LIBRARY CIRCULATION REPORT                                 \n");
        sb.append("                      Generated: ").append(sdf.format(new Date())).append("\n");
        sb.append("========================================================================================\n\n");

        List<IssuedBook> issues = libraryService.getIssuedBooks();
        sb.append(String.format("%-8s | %-10s | %-8s | %-12s | %-12s | %-10s | %-8s\n",
                "Issue ID", "Member ID", "Book ID", "Issue Date", "Due Date", "Status", "Fine"));
        sb.append("----------------------------------------------------------------------------------------\n");

        int activeCount = 0;
        int returnedCount = 0;
        double totalFines = 0.0;
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");

        for (IssuedBook ib : issues) {
            String status = ib.isReturned() ? "RETURNED" : "ACTIVE";
            if (ib.isReturned()) returnedCount++; else activeCount++;
            totalFines += ib.getFine();

            sb.append(String.format("%-8d | %-10d | %-8d | %-12s | %-12s | %-10s | ₹%-7.2f\n",
                    ib.getIssueId(), ib.getMemberId(), ib.getBookId(),
                    df.format(ib.getIssueDate()), df.format(ib.getDueDate()), status, ib.getFine()));
        }

        sb.append("----------------------------------------------------------------------------------------\n");
        sb.append(String.format("Total Checkouts: %d | Active Loans: %d | Returned: %d | Total Fines Collected: ₹%.2f\n",
                issues.size(), activeCount, returnedCount, totalFines));
        sb.append("========================================================================================\n");
        return sb.toString();
    }

    public String generateInventoryReport() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Inventory inv = libraryService.getInventory();
        List<Book> books = libraryService.getBookService().getAllBooks();

        sb.append("========================================================================================\n");
        sb.append("                   SMART LIBRARY INVENTORY UTILIZATION REPORT                           \n");
        sb.append("                   Generated: ").append(sdf.format(new Date())).append("\n");
        sb.append("========================================================================================\n\n");

        sb.append(String.format("%-8s | %-26s | %-16s | %-10s | %-8s | %-8s | %-8s\n",
                "Book ID", "Title", "Category", "Type", "Total", "Avail", "Issued"));
        sb.append("----------------------------------------------------------------------------------------\n");

        int grandTotal = 0;
        int grandAvailable = 0;

        for (Book b : books) {
            int tot = b.getTotalCopies();
            int avail = b.getAvailableCopies();
            int iss = tot - avail;
            grandTotal += tot;
            grandAvailable += avail;

            sb.append(String.format("%-8d | %-26s | %-16s | %-10s | %-8d | %-8d | %-8d\n",
                    b.getBookId(),
                    (b.getTitle().length() > 26 ? b.getTitle().substring(0, 23) + "..." : b.getTitle()),
                    b.getCategory(), b.getBookType(), tot, avail, iss));
        }

        int grandIssued = grandTotal - grandAvailable;
        double utilPercentage = inv.calculateUtilizationPercentage();

        sb.append("----------------------------------------------------------------------------------------\n");
        sb.append(String.format("Catalog Titles: %d\n", books.size()));
        sb.append(String.format("Total Physical/Digital Copies : %d\n", grandTotal));
        sb.append(String.format("Total Available Copies        : %d\n", grandAvailable));
        sb.append(String.format("Total Currently Issued Copies : %d\n", grandIssued));
        sb.append(String.format("Overall Inventory Utilization : %.2f%%\n", utilPercentage));
        sb.append("========================================================================================\n");
        return sb.toString();
    }

    public String generateFineReport() {
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        sb.append("========================================================================================\n");
        sb.append("                     SMART LIBRARY OVERDUE & FINE REPORT                                \n");
        sb.append("                     Generated: ").append(sdf.format(new Date())).append("\n");
        sb.append("========================================================================================\n\n");

        List<IssuedBook> issues = libraryService.getIssuedBooks();
        Date now = new Date();
        int overdueCount = 0;
        double potentialFines = 0.0;

        sb.append(String.format("%-8s | %-18s | %-10s | %-22s | %-10s | %-8s\n",
                "Issue ID", "Member Name", "Member Type", "Book Title", "Overdue", "Fine"));
        sb.append("----------------------------------------------------------------------------------------\n");

        for (IssuedBook ib : issues) {
            if (!ib.isReturned() && now.after(ib.getDueDate())) {
                try {
                    Member m = libraryService.getMemberService().getMemberById(ib.getMemberId());
                    Book b = libraryService.getBookService().getBookById(ib.getBookId());
                    long diff = now.getTime() - ib.getDueDate().getTime();
                    int days = (int) Math.ceil((double) diff / (1000 * 60 * 60 * 24));
                    double fine = m.calculateFine(days);

                    overdueCount++;
                    potentialFines += fine;

                    sb.append(String.format("%-8d | %-18s | %-10s | %-22s | %-7d days | ₹%-7.2f\n",
                            ib.getIssueId(), m.getName(), m.getMemberType(),
                            (b.getTitle().length() > 22 ? b.getTitle().substring(0, 19) + "..." : b.getTitle()),
                            days, fine));
                } catch (Exception ignored) {}
            }
        }

        sb.append("----------------------------------------------------------------------------------------\n");
        sb.append(String.format("Active Overdue Loans: %d | Total Accrued Overdue Fines: ₹%.2f\n", overdueCount, potentialFines));
        sb.append("========================================================================================\n");
        return sb.toString();
    }

    public String generateComprehensiveAuditReport() {
        return generateCirculationReport() + "\n\n" +
               generateInventoryReport() + "\n\n" +
               generateFineReport();
    }

    public void exportReportToFile(String destinationPath) throws IOException {
        String content = generateComprehensiveAuditReport();
        FileReportWriter.exportReport(content, destinationPath);
    }
}
