package service;

import database.DatabaseManager;
import exception.DuplicateReservationException;
import exception.InvalidInputException;
import model.Reservation;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

/**
 * Service managing book reservation waitlists.
 * Implements FIFO waitlist fulfillment and guards against duplicate active reservations.
 */
public class ReservationService {

    private final List<Reservation> reservationList;
    private final DatabaseManager dbManager;
    private int nextLocalId = 1000;

    public ReservationService(DatabaseManager dbManager) {
        this.reservationList = new ArrayList<Reservation>();
        this.dbManager = dbManager;
        loadReservationsFromDatabase();
    }

    public void loadReservationsFromDatabase() {
        if (dbManager != null) {
            try {
                List<Reservation> loaded = dbManager.getAllReservations();
                reservationList.clear();
                reservationList.addAll(loaded);
            } catch (SQLException e) {
                System.err.println("Warning: Could not load reservations from DB: " + e.getMessage());
            }
        }
    }

    /**
     * Creates a new reservation, verifying that the member does not already have an active reservation.
     */
    public synchronized Reservation reserveBook(int memberId, int bookId)
            throws DuplicateReservationException, InvalidInputException, SQLException {
        
        // Check for existing active reservation for the same member and book
        for (Reservation res : reservationList) {
            if (res.getMemberId() == memberId && res.getBookId() == bookId && res.isActive()) {
                throw new DuplicateReservationException(
                    "Duplicate Reservation: Member #" + memberId + " already has an active reservation (#" + res.getReservationId() + ") for Book #" + bookId
                );
            }
        }

        Reservation newRes = new Reservation(++nextLocalId, memberId, bookId, new Date(), "ACTIVE");

        if (dbManager != null) {
            dbManager.insertReservation(newRes);
        }

        reservationList.add(newRes);
        return newRes;
    }

    /**
     * Cancels an active reservation.
     */
    public synchronized boolean cancelReservation(int reservationId) throws InvalidInputException, SQLException {
        for (Reservation res : reservationList) {
            if (res.getReservationId() == reservationId) {
                if (!res.isActive()) {
                    throw new InvalidInputException("Reservation #" + reservationId + " is already " + res.getStatus() + " and cannot be cancelled.");
                }
                res.setStatus("CANCELLED");
                if (dbManager != null) {
                    dbManager.updateReservationStatus(reservationId, "CANCELLED");
                }
                return true;
            }
        }
        throw new InvalidInputException("Reservation #" + reservationId + " not found.");
    }

    /**
     * Retrieves the next active reservation in FIFO order for a specific book ID.
     */
    public synchronized Reservation getNextActiveReservation(int bookId) {
        for (Reservation res : reservationList) {
            if (res.getBookId() == bookId && res.isActive()) {
                return res;
            }
        }
        return null;
    }

    /**
     * Fulfills the next active reservation when a returned copy arrives.
     */
    public synchronized Reservation fulfillNextReservation(int bookId) throws SQLException {
        Reservation next = getNextActiveReservation(bookId);
        if (next != null) {
            next.setStatus("FULFILLED");
            if (dbManager != null) {
                dbManager.updateReservationStatus(next.getReservationId(), "FULFILLED");
            }
        }
        return next;
    }

    public List<Reservation> getActiveReservationsForBook(int bookId) {
        List<Reservation> list = new ArrayList<Reservation>();
        for (Reservation r : reservationList) {
            if (r.getBookId() == bookId && r.isActive()) {
                list.add(r);
            }
        }
        return list;
    }

    public List<Reservation> getAllReservations() {
        return new ArrayList<Reservation>(reservationList);
    }
}
