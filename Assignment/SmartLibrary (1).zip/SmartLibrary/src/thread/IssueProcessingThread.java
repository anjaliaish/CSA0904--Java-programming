package thread;

import model.Inventory;
import java.util.List;

/**
 * Thread demonstrating concurrent book checkout processing with high priority.
 * Competes for shared Inventory monitor and demonstrates wait() when stock is 0.
 */
public class IssueProcessingThread extends Thread {

    private final Inventory inventory;
    private final int bookId;
    private final List<String> executionLogs;
    private boolean successful;

    public IssueProcessingThread(String threadName, Inventory inventory, int bookId, List<String> logs) {
        super(threadName);
        this.inventory = inventory;
        this.bookId = bookId;
        this.executionLogs = logs;
        this.successful = false;
        // Explicit demonstration of Thread Priority
        this.setPriority(Thread.MAX_PRIORITY); // Priority 10
    }

    @Override
    public void run() {
        String startMsg = "[" + getName() + "] (Priority " + getPriority() + ") Started issue request for Book #" + bookId;
        if (executionLogs != null) executionLogs.add(startMsg);
        System.out.println(startMsg);

        try {
            // Demonstrates synchronized wait() on shared inventory resource
            successful = inventory.waitAndIssueBook(bookId, getName(), executionLogs);
        } catch (InterruptedException e) {
            String err = "[" + getName() + "] Interrupted during wait(): " + e.getMessage();
            if (executionLogs != null) executionLogs.add(err);
            System.err.println(err);
        }
    }

    public boolean isSuccessful() {
        return successful;
    }
}
