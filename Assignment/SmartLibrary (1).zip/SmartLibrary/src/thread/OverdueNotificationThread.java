package thread;

import model.Notification;
import service.LibraryService;

import java.util.List;

/**
 * Background daemon thread running overdue scanning with low priority.
 * Demonstrates Thread.MIN_PRIORITY (Priority 1) and automated notification generation.
 */
public class OverdueNotificationThread extends Thread {

    private final LibraryService libraryService;
    private final List<String> executionLogs;
    private int notificationsGenerated;

    public OverdueNotificationThread(String threadName, LibraryService libraryService, List<String> logs) {
        super(threadName);
        this.libraryService = libraryService;
        this.executionLogs = logs;
        this.notificationsGenerated = 0;
        // Explicit demonstration of Thread Priority
        this.setPriority(Thread.MIN_PRIORITY); // Priority 1
    }

    @Override
    public void run() {
        String startMsg = "[" + getName() + "] (Priority " + getPriority() + ") Background overdue scanner started...";
        if (executionLogs != null) executionLogs.add(startMsg);
        System.out.println(startMsg);

        try {
            List<Notification> newNotifs = libraryService.scanAndGenerateOverdueNotifications();
            notificationsGenerated = newNotifs.size();
            String resMsg = "[" + getName() + "] Scanned circulation records: Generated " + notificationsGenerated + " overdue notice(s).";
            if (executionLogs != null) executionLogs.add(resMsg);
            System.out.println(resMsg);

            for (Notification n : newNotifs) {
                String notifLine = "   -> " + n.formatNotification();
                if (executionLogs != null) executionLogs.add(notifLine);
                System.out.println(notifLine);
            }
        } catch (Exception e) {
            String err = "[" + getName() + "] Error during scan: " + e.getMessage();
            if (executionLogs != null) executionLogs.add(err);
        }
    }

    public int getNotificationsGenerated() {
        return notificationsGenerated;
    }
}
