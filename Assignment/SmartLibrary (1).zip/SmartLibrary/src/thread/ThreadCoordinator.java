package thread;

import model.Inventory;
import service.LibraryService;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Coordinates and demonstrates multithreading, synchronization, wait()/notifyAll(),
 * and thread priority mechanisms across concurrent library workflows.
 */
public class ThreadCoordinator {

    private final Inventory inventory;
    private final LibraryService libraryService;

    public ThreadCoordinator(Inventory inventory, LibraryService libraryService) {
        this.inventory = inventory;
        this.libraryService = libraryService;
    }

    /**
     * Executes the comprehensive multithreading demonstration:
     * 1. Sets Book #999 stock to 0.
     * 2. Starts IssueProcessingThread (Priority 10) -> enters wait().
     * 3. Starts ReturnThread -> increases stock and calls notifyAll().
     * 4. IssueProcessingThread wakes, verifies stock > 0, and completes issue.
     * 5. Runs OverdueNotificationThread (Priority 1) for automated background notice generation.
     */
    public List<String> runMultithreadingDemo() {
        final List<String> logs = Collections.synchronizedList(new ArrayList<String>());

        logs.add("================================================================================");
        logs.add("              MULTITHREADING, SYNCHRONIZATION & WAIT/NOTIFY DEMO               ");
        logs.add("================================================================================");
        logs.add("Setting up test condition: Book #999 registered with 0 available copies in shared Inventory.");

        final int demoBookId = 999;
        inventory.registerBookStock(demoBookId, 3, 0); // Total 3, Available 0

        // 1. Create and start IssueProcessingThread (Priority 10)
        IssueProcessingThread issueThread = new IssueProcessingThread("IssueWorker-1", inventory, demoBookId, logs);
        logs.add("\n[Coordinator] Spawning IssueProcessingThread with Priority: " + issueThread.getPriority() + " (MAX_PRIORITY)");
        issueThread.start();

        // Brief delay to allow issueThread to reach wait() state
        try {
            Thread.sleep(400);
        } catch (InterruptedException ignored) {}

        logs.add("\n[Coordinator] Inventory check: Book #999 available copies = " + inventory.getAvailableCopies(demoBookId));
        logs.add("[Coordinator] IssueWorker-1 is currently BLOCKED in wait() state waiting for stock.");

        // 2. Simulate concurrent Return Operation on a separate thread
        Thread returnThread = new Thread(new Runnable() {
            @Override
            public void run() {
                String rMsg = "[ReturnWorker-1] (Priority " + Thread.currentThread().getPriority() + ") Received physical book return for Book #" + demoBookId;
                logs.add(rMsg);
                System.out.println(rMsg);
                try {
                    Thread.sleep(300); // Simulate check-in processing time
                } catch (InterruptedException ignored) {}
                inventory.returnBookAndNotify(demoBookId, "ReturnWorker-1", logs);
            }
        }, "ReturnWorker-1");

        returnThread.setPriority(Thread.NORM_PRIORITY); // Priority 5
        logs.add("\n[Coordinator] Spawning ReturnWorker-1 with Priority: " + returnThread.getPriority() + " (NORM_PRIORITY)");
        returnThread.start();

        // Wait for both threads to finish
        try {
            issueThread.join(2500);
            returnThread.join(2500);
        } catch (InterruptedException e) {
            logs.add("[Coordinator] Thread join interrupted: " + e.getMessage());
        }

        logs.add("\n[Coordinator] Issue & Return synchronization cycle completed successfully.");
        logs.add("[Coordinator] Remaining Available Copies for Book #" + demoBookId + ": " + inventory.getAvailableCopies(demoBookId));

        // 3. Run OverdueNotificationThread (Priority 1)
        OverdueNotificationThread overdueThread = new OverdueNotificationThread("OverdueDaemon-1", libraryService, logs);
        logs.add("\n[Coordinator] Spawning OverdueNotificationThread with Priority: " + overdueThread.getPriority() + " (MIN_PRIORITY)");
        overdueThread.start();

        try {
            overdueThread.join(2500);
        } catch (InterruptedException ignored) {}

        logs.add("\n================================================================================");
        logs.add("                           DEMONSTRATION SUMMARY                                ");
        logs.add(" - Shared Resource : Inventory (Hashtable<Integer, Integer>)");
        logs.add(" - Synchronization : synchronized methods prevent race conditions on stock decrements");
        logs.add(" - Inter-thread IPC: wait() when stock == 0; notifyAll() on returnBook()");
        logs.add(" - Thread Priority : IssueProcessingThread (10) vs OverdueNotificationThread (1)");
        logs.add("================================================================================");

        return new ArrayList<String>(logs);
    }
}
