package util;

import model.Book;
import model.Inventory;
import model.IssuedBook;
import model.Member;
import model.Notification;
import model.Reservation;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Handles full library state backup and restore via Java Object Serialization.
 * Demonstrates ObjectOutputStream, ObjectInputStream, Serializable, and SHA-256 state verification.
 */
public class BackupManager {

    /**
     * Serializable container holding full snapshot state.
     */
    public static class LibraryState implements Serializable {
        private static final long serialVersionUID = 1L;

        private Map<Integer, Member> members;
        private List<Book> books;
        private List<Reservation> reservations;
        private List<IssuedBook> issuedBooks;
        private Inventory inventory;
        private List<Notification> notifications;
        private Date timestamp;
        private String integrityChecksum;

        public LibraryState(Map<Integer, Member> members,
                            List<Book> books,
                            List<Reservation> reservations,
                            List<IssuedBook> issuedBooks,
                            Inventory inventory,
                            List<Notification> notifications) {
            this.members = (members != null) ? new HashMap<Integer, Member>(members) : new HashMap<Integer, Member>();
            this.books = (books != null) ? new ArrayList<Book>(books) : new ArrayList<Book>();
            this.reservations = (reservations != null) ? new ArrayList<Reservation>(reservations) : new ArrayList<Reservation>();
            this.issuedBooks = (issuedBooks != null) ? new ArrayList<IssuedBook>(issuedBooks) : new ArrayList<IssuedBook>();
            this.inventory = inventory;
            this.notifications = (notifications != null) ? new ArrayList<Notification>(notifications) : new ArrayList<Notification>();
            this.timestamp = new Date();
            this.integrityChecksum = HashUtil.computeSHA256(
                    "MEMBERS:" + this.members.size() + 
                    "|BOOKS:" + this.books.size() + 
                    "|RES:" + this.reservations.size() +
                    "|TIME:" + this.timestamp.getTime()
            );
        }

        public Map<Integer, Member> getMembers() { return members; }
        public List<Book> getBooks() { return books; }
        public List<Reservation> getReservations() { return reservations; }
        public List<IssuedBook> getIssuedBooks() { return issuedBooks; }
        public Inventory getInventory() { return inventory; }
        public List<Notification> getNotifications() { return notifications; }
        public Date getTimestamp() { return timestamp; }
        public String getIntegrityChecksum() { return integrityChecksum; }
    }

    /**
     * Saves library state to a serialized binary file.
     */
    public static void saveBackup(LibraryState state, String filePath) throws IOException {
        File file = new File(filePath);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (FileOutputStream fos = new FileOutputStream(file);
             ObjectOutputStream oos = new ObjectOutputStream(fos)) {
            oos.writeObject(state);
            oos.flush();
        }
    }

    /**
     * Restores library state from a serialized binary file.
     */
    public static LibraryState loadBackup(String filePath) throws IOException, ClassNotFoundException {
        File file = new File(filePath);
        if (!file.exists()) {
            throw new IOException("Backup file does not exist: " + filePath);
        }

        try (FileInputStream fis = new FileInputStream(file);
             ObjectInputStream ois = new ObjectInputStream(fis)) {
            Object obj = ois.readObject();
            if (obj instanceof LibraryState) {
                return (LibraryState) obj;
            } else {
                throw new IOException("Invalid backup payload format.");
            }
        }
    }
}
