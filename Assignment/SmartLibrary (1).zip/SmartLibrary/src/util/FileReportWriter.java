package util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Demonstrates Java I/O Streams:
 * 
 * 1. Character Streams (FileWriter, BufferedWriter, FileReader, BufferedReader):
 *    - Operates on 16-bit Unicode characters.
 *    - Ideal for textual reports, human-readable summaries, logs, and formatted data.
 * 
 * 2. Byte Streams (FileInputStream, FileOutputStream):
 *    - Operates on 8-bit raw bytes.
 *    - Ideal for binary files, serialized objects, media, and raw checksum processing.
 */
public class FileReportWriter {

    /**
     * Exports a text report using Character Streams (BufferedWriter & FileWriter).
     */
    public static void exportReport(String reportContent, String filePath) throws IOException {
        File file = new File(filePath);
        File parent = file.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, false))) {
            writer.write(reportContent);
            writer.flush();
        }
    }

    /**
     * Reads a text report back using Character Streams (BufferedReader & FileReader).
     */
    public static String readReport(String filePath) throws IOException {
        File file = new File(filePath);
        if (!file.exists()) {
            throw new IOException("Report file not found: " + filePath);
        }

        StringBuilder sb = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append("\n");
            }
        }
        return sb.toString();
    }

    /**
     * Creates a binary byte-level clone of a file using Byte Streams (FileInputStream & FileOutputStream).
     */
    public static void copyBinaryFile(String sourcePath, String destPath) throws IOException {
        File source = new File(sourcePath);
        if (!source.exists()) {
            throw new IOException("Source file not found: " + sourcePath);
        }

        File dest = new File(destPath);
        File parent = dest.getParentFile();
        if (parent != null && !parent.exists()) {
            parent.mkdirs();
        }

        try (FileInputStream fis = new FileInputStream(source);
             FileOutputStream fos = new FileOutputStream(dest)) {
            byte[] buffer = new byte[4096];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                fos.write(buffer, 0, bytesRead);
            }
            fos.flush();
        }
    }
}
