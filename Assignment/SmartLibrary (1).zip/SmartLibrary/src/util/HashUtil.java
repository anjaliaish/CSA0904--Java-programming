package util;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Cryptographic Hashing Utility using SHA-256.
 * 
 * ARCHITECTURAL DISTINCTION:
 * 1. Collection Hashing (HashMap, HashSet, Hashtable):
 *    - Relies on Object.hashCode() to distribute objects across integer bucket slots.
 *    - Fast, 32-bit integer, non-cryptographic, subject to collisions.
 * 
 * 2. Cryptographic Hashing (HashUtil - SHA-256):
 *    - 256-bit one-way cryptographic hash function.
 *    - Collision-resistant and irreversible, used for data integrity, file verification,
 *      and credential security.
 */
public class HashUtil {

    private static final String HASH_ALGORITHM = "SHA-256";

    /**
     * Computes the SHA-256 cryptographic hexadecimal hash of a given string.
     */
    public static String computeSHA256(String data) {
        if (data == null) return "";
        try {
            MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
            byte[] encodedHash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(encodedHash);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available in this JRE environment", e);
        }
    }

    /**
     * Computes the SHA-256 checksum of a file using Byte Streams (FileInputStream).
     */
    public static String computeFileChecksum(File file) throws IOException {
        if (!file.exists()) {
            throw new IOException("File does not exist: " + file.getAbsolutePath());
        }
        try {
            MessageDigest digest = MessageDigest.getInstance(HASH_ALGORITHM);
            try (FileInputStream fis = new FileInputStream(file)) {
                byte[] byteArray = new byte[1024];
                int bytesCount;
                while ((bytesCount = fis.read(byteArray)) != -1) {
                    digest.update(byteArray, 0, bytesCount);
                }
            }
            byte[] bytes = digest.digest();
            return bytesToHex(bytes);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("SHA-256 algorithm not available in this JRE environment", e);
        }
    }

    private static String bytesToHex(byte[] hash) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : hash) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) {
                hexString.append('0');
            }
            hexString.append(hex);
        }
        return hexString.toString();
    }
}
