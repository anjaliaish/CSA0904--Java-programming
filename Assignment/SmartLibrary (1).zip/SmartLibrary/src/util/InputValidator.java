package util;

import exception.InvalidInputException;
import java.util.regex.Pattern;

/**
 * Validates user inputs across all AWT GUI forms.
 * Throws InvalidInputException on syntax or constraint violations.
 */
public class InputValidator {

    private static final Pattern EMAIL_PATTERN = 
        Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,6}$");

    public static int validatePositiveInt(String input, String fieldName) throws InvalidInputException {
        if (input == null || input.trim().isEmpty()) {
            throw new InvalidInputException(fieldName + " cannot be empty.");
        }
        String clean = input.trim();
        // Allow user-friendly prefix like 'B101' or 'M101' or '#101'
        if (clean.matches("^[A-Za-z#]+\\d+$")) {
            clean = clean.replaceAll("^[A-Za-z#]+", "");
        }
        try {
            int value = Integer.parseInt(clean);
            if (value <= 0) {
                throw new InvalidInputException(fieldName + " must be a positive integer (> 0).");
            }
            return value;
        } catch (NumberFormatException e) {
            throw new InvalidInputException(fieldName + " must be a numeric integer (e.g. 101 or 201).");
        }
    }

    public static int validateNonNegativeInt(String input, String fieldName) throws InvalidInputException {
        if (input == null || input.trim().isEmpty()) {
            throw new InvalidInputException(fieldName + " cannot be empty.");
        }
        String clean = input.trim();
        if (clean.matches("^[A-Za-z#]+\\d+$")) {
            clean = clean.replaceAll("^[A-Za-z#]+", "");
        }
        try {
            int value = Integer.parseInt(clean);
            if (value < 0) {
                throw new InvalidInputException(fieldName + " cannot be negative.");
            }
            return value;
        } catch (NumberFormatException e) {
            throw new InvalidInputException(fieldName + " must be a numeric integer.");
        }
    }

    public static String validateNonEmptyString(String input, String fieldName) throws InvalidInputException {
        if (input == null || input.trim().isEmpty()) {
            throw new InvalidInputException(fieldName + " cannot be empty.");
        }
        return input.trim();
    }

    public static String validateEmail(String email) throws InvalidInputException {
        if (email == null || email.trim().isEmpty()) {
            throw new InvalidInputException("Email address cannot be empty.");
        }
        String trimmed = email.trim();
        if (!EMAIL_PATTERN.matcher(trimmed).matches()) {
            throw new InvalidInputException("Invalid email format. Expected format: user@domain.com");
        }
        return trimmed;
    }
}
